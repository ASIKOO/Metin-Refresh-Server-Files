--Évènement automatique : Cor draconis (brut) (Test)
--Création pour le gérant de Ping-Hosting.com

quest CorDraconis begin
	state start begin

		when kill with CorDraconis.is_time2drop() begin
			local setting = CorDraconis.setting()
			--Liste des Monstres/Metins/boss droppant les objets durant l'évent.
			for i=1,table.getn(setting.mob2kill) do
				if setting.mob2kill[i][1] == npc.get_race() and number(1,100) <= setting.mob2kill[i][2] then
					local alea2 = number(1,100)
					--Liste des objets dropable durant l'évent.
					for j=1,table.getn(setting.drop) do
						if alea2 <= setting.drop[j][2] then
							pc.give_item2(setting.drop[j][1], 1)
							break
						end
					end
				end
			end
		end
		
		-- Informations chez Yonah
		when 20005.chat."La grande richesse des pirates" begin
			if pc.is_gm() then
				topsay(20005)
				say("Ceci est un test effectué")
				say("par le [GA]Arkade.")
				say("La création d'un évènement est en cours..")
				say("")
				say("Merci de votre patience.")
				wait()
				topsay(20005)
			end
		end
		
	end
	

state __FUNC__ begin
		function setting()
			return
			{
				["drop"] = { --Liste des objets dropable durant l'évent.
						{50255, 50}, --Cor draconis (brut)
				},
				
				["mob2kill"] = { --Liste des Monstres/Metins/boss droppant les objets durant l'évent.
					{8041, 50}, --Metin pascale () (METIN)
				},
			}
		end
		
		function is_time2drop()
			local h_i = 12 --Début de l'évent.
			local h_f = 23 --Fin de l'évent.
			local b = os.date("%H") - math.floor(os.date("%H") / h_f)*h_f >= h_i ;
			return b
		end
		
	end
end



--Évènement automatique : Cor draconis (brut) (Test)
--Création pour le gérant de Ping-Hosting.com