--Coffres d'évènements & Gros BOSS
--Création pour le gérant de Ping-Hosting.com

quest Coffres_Metin2BE begin
	state start begin
	
			function Coffres_Event_Boss(idCoffre, idRecompense) --- idCoffre , idRecompense
				if idCoffre == 71144 then --Coffre de noël
					local listeRecompense = {
						[0] = { 25040, 0, 1}, --Parchemin de bénédiction
						[1] = { 71101, 0, 20}, --Potion de Célérité (x20)
						[2] = { 71107, 0, 1}, --Fruit de la vie
						[3] = { 39033, 0, 1}, --Parchemin de correction
						[4] = { 27124, 0, 5}, --Bandage x5
						[5] = { 38010, 0, 1}, --Paquet de Yangs (25m)
					}
					return listeRecompense[idRecompense]
				end
			
				if idCoffre == 50126 then --Coffre Mystérieux
					local listeRecompense = {
						[0] = { 71125, 0, 1}, --Sceau Sanglier pugnace
						[1] = { 25041, 0, 10}, --Pierre magique
						[2] = { 27124, 0, 10}, --Bandage
						[3] = { 72311, 0, 30}, --Bénédiction du Dragon
						[4] = { 39007, 0, 10}, --Manuel du Forgeron
						[5] = { 39022, 0, 10}, --Parchemin du dieu dragon
						[6] = { 25040, 0, 10}, --Parchemin de bénédiction
						[7] = { 72319, 0, 10}, --Extension d'inventaire
						[8] = { 71018, 0, 30}, --Bénédiction de Vie 
						[9] = { 72045, 0, 1}, --Livre du chef 3h
						[10] = { 38011, 0, 1}, --Paquet de Yangs (50m)
						[11] = { 55009, 0, 10}, --Malle livres de familier
						[12] = { 50126, 0, 1}, --Coffre Mystérieux
					}
					return listeRecompense[idRecompense]
				end
			
				if idCoffre == 50267 then --Coffre d'or Okey
					local listeRecompense = {
						[0] = { 50126, 0, 5}, --Malle livres de familier
						[1] = { 38011, 0, 1}, --Paquet de Yangs (50M)
						[2] = { 25041, 0, 30}, --Pierre magique
						[3] = { 70058, 0, 5}, --Anneau de téléportation
						[4] = { 80017, 0, 25}, --Bon de DC (50)
						[5] = { 27124, 0, 30}, --Bandage
						[6] = { 72319, 0, 25}, --Extension d'inventaire
						[7] = { 100500, 0, 10}, --Haricot dragon rose
						[8] = { 50323, 0, 1}, --Coffre : Livre. de parade
						[9] = { 50324, 0, 1}, --Coffre : Livre de bonus
						[10] = { 55404, 0, 1}, --Oeuf de Némère
						[11] = { 55403, 0, 1}, --Oeuf de Razador
						[12] = { 85003, 0, 1}, --Etole d'expert (noble)
						[13] = { 79506, 0, 1}, --Set de cartes Okey
						[14] = { 51506, 0, 5}, --Cor draconis (Mythique)
						[15] = { 51505, 0, 5}, --Cor draconis (Précieux)
						[16] = { 30616, 0, 3}, --Dioxyde de titane
						[17] = { 30617, 0, 3}, --Agate
						[18] = { 30618, 0, 3}, --Pierre de lune
						[19] = { 27992, 0, 5}, --Perle blanche
						[20] = { 55405, 0, 1}, --Oeuf de dragon bleu
						[21] = { 71153, 0, 1}, --Potion de sagesse
						[22] = { 71223, 0, 1}, --Monture SamSara
					}
					return listeRecompense[idRecompense]
				end
			
				if idCoffre == 50268 then --Coffre d'argent Okey
					local listeRecompense = {
						[0] = { 71193, 0, 1}, --Sceau Eclair
						[1] = { 38010, 0, 1}, --Paquet de Yangs (25m)
						[2] = { 25041, 0, 20}, --Pierre magique
						[3] = { 70058, 0, 3}, --Anneau de téléportation
						[4] = { 27125, 0, 15}, --Bandage
						[5] = { 39028, 0, 2}, --Malle livre de familier
						[6] = { 71192, 0, 1}, --Sceau de Tonnerre
						[7] = { 50323, 0, 1}, --Coffre : Livre. de parade
						[8] = { 50324, 0, 1}, --Coffre : Livre de bonus
						[9] = { 55404, 0, 1}, --Oeuf de Némère
						[10] = { 55403, 0, 1}, --Oeuf de Razador
						[11] = { 85001, 0, 1}, --Etole d'expert (noble)
						[12] = { 79506, 0, 1}, --Set de cartes Okey
						[13] = { 51503, 0, 3}, --Cor draconis (normal)
						[14] = { 51504, 0, 3}, --Cor draconis (noble)
						[15] = { 55402, 0, 1}, --Oeuf d'araignée
						[16] = { 27994, 0, 5}, --Perle de sang
						[17] = { 27993, 0, 5}, --Perle bleue
						[18] = { 71153, 0, 1}, --Potion de sagesse
					}
					return listeRecompense[idRecompense]
				end
			
				if idCoffre == 50269 then --Coffre de Bronze Okey
					local listeRecompense = {
						[0] = { 79506, 0, 1}, --Set de cartes Okey
						[1] = { 38010, 0, 1}, --Paquet de Yangs (25M)
					}
					return listeRecompense[idRecompense]
				end
			
				if idCoffre == 50266 then --Coffre de Jotun
					local listeRecompense = {
						[0] = { 20000, 0, 1}, --Armure corne du diable
						[1] = { 21090, 0, 1}, --Armure de général
						[2] = { 20500, 0, 1}, --Armure plates d'os
						[3] = { 20750, 0, 1}, --Vêtement doré
						[4] = { 20250, 0, 1}, --Tenue cavalier dragon
						[5] = { 15370, 0, 1}, --Chausses d'euphorie
						[6] = { 15430, 0, 1}, --Bottes d'oiseau-glace
						[7] = { 30618, 0, 5}, --Pierre de lune
						[8] = { 30617, 0, 5}, --Agate
						[9] = { 30616, 0, 5}, --Dioxyde de titane
						[10] = { 30614, 0, 5}, --Teinture noire
						[11] = { 30615, 0, 5}, --Teinture blanche
						[12] = { 30602, 0, 5}, --Teinture bleue
						[13] = { 30192, 0, 20}, --Latex
						[14] = { 50525, 0, 10}, --Pierre d'âme+
						[15] = { 27992, 0, 10}, --Perle blanche
						[16] = { 27993, 0, 10}, --Perle bleue
						[17] = { 27994, 0, 10}, --Perle de sang
						[18] = { 50323, 0, 1}, --Coffre : Livre. de parade
						[19] = { 50324, 0, 1}, --Coffre : Livre de bonus
						[20] = { 50515, 0, 1}, --Livre de parade
						[21] = { 50514, 0, 1}, --Livre de bonus
						[22] = { 39004, 0, 10}, --Orbe de bénédiction
						[23] = { 55003, 0, 5}, --Livre de jeune familier
						[24] = { 55004, 0, 5}, --Livre de famil. sauvage
						[25] = { 55005, 0, 5}, --Livre de famil. vaillant
						[26] = { 30611, 0, 3}, --Sangles massives
						[27] = { 30610, 0, 3}, --Mithril
						[28] = { 25040, 0, 10}, --Parchemin de bénédiction
					}
					return listeRecompense[idRecompense]
				end
			
				if idCoffre == 50270 then --Coffre de la reine meley
					local listeRecompense = {
						[0] = { 15370, 0, 1}, --Chausses d'euphorie
						[1] = { 15430, 0, 1}, --Bottes d'oiseau-glace
						[2] = { 5340, 0, 1}, --Cloche dragon fantôme
						[3] = { 7180, 0, 1}, --Event. dragon couché
						[4] = { 2370, 0, 1}, --Arc du phénix
						[5] = { 470, 0, 1}, --Lame dent de dragon
						[6] = { 21540, 0, 1}, --Heaume du Bois Vert
						[7] = { 12680, 0, 1}, --Chapeau d'éclat d'âme
						[8] = { 12400, 0, 1}, --Capuchon arachnoïde
						[9] = { 55406, 0, 1}, --Oeuf dragon rouge
						[10] = { 30550, 0, 10}, --Lanière bleue x10
						[11] = { 55003, 0, 1}, --Livre de jeune familier
						[12] = { 55004, 0, 1}, --Livre de famil. sauvage
						[13] = { 55005, 0, 1}, --Livre de famil. vaillant
						[14] = { 30620, 0, 5}, --Corne de dragon rouge x3
						[15] = { 30621, 0, 5}, --Ecaille de dragon rouge x3
						[16] = { 50296, 0, 1}, --Boîte de parade
						[17] = { 50297, 0, 1}, --Boîte de bonus
						[18] = { 27992, 0, 10}, --Perle blanche
						[19] = { 27993, 0, 10}, --Perle bleue
						[20] = { 27994, 0, 10}, --Perle de sang
						[21] = { 30192, 0, 10}, --Latex
						[22] = { 39004, 0, 10}, --Orbe de bénédiction
						[23] = { 70031, 0, 10}, --Traité d'escrime
						[24] = { 300, 0, 1}, --Ultima White+0
					}
					return listeRecompense[idRecompense]
				end
			
				if idCoffre == 71150 then --Oeuf magique
					local listeRecompense = {
						[0] = { 70065, 0, 1}, --Transfert de bonus
						[1] = { 18900, 0, 1}, --Pierre à flammes rouges
						[2] = { 55003, 0, 5}, --Livre de jeune familier
						[3] = { 55004, 0, 5}, --Livre de famil. sauvage
						[4] = { 55005, 0, 5}, --Livre de famil. vaillant
						[5] = { 50323, 0, 1}, --Coffre livre de parade
						[6] = { 50324, 0, 1}, --Coffre livre de bonus
						[7] = { 27124, 0, 10}, --Bandage
						[8] = { 27992, 0, 10}, --Perle blanche
						[9] = { 27993, 0, 10}, --Perle bleue
						[10] = { 27994, 0, 10}, --Perle de sang
						[11] = { 72319, 0, 10}, --Extension d'inventaire
						[12] = { 55009, 0, 1}, --Malle livres de familier
						[13] = { 72045, 0, 1}, --Livre du chef 3h
						[14] = { 100300, 0, 10}, --Haricot dragon vert
						[15] = { 100500, 0, 10}, --Haricot dragon rose
						[16] = { 38011, 0, 1}, --Paquet de Yangs (50M)
						[17] = { 72726, 0, 1}, --Elixir du soleil (sp)
						[18] = { 72730, 0, 1}, --Elixir de la lune (sp)
						[19] = { 100400, 0, 10}, --Haricot dragon bleu
					}
					return listeRecompense[idRecompense]
				end
			
				if idCoffre == 55009 then --Malles livres de familier
					local listeRecompense = {
						[0] = { 55010, 0, 1}, --Résistance (Guerrier)
						[1] = { 55011, 0, 1}, --Résistance (Sura)
						[2] = { 55012, 0, 1}, --Résistance (Ninja)
						[3] = { 55013, 0, 1}, --Résistance (Chamane)
						[4] = { 55014, 0, 1}, --Résistance (Lycan)
						[5] = { 55015, 0, 1}, --Livre de Berserker
						[6] = { 55016, 0, 1}, --Livre d'anti-magie
						[7] = { 55017, 0, 1}, --Livre d'accélération
						[8] = { 55018, 0, 1}, --Livre du drill
						[9] = { 55019, 0, 1}, --Livre du renouvellement
						[10] = { 55020, 0, 1}, --Livre de vampire
						[10] = { 55021, 0, 1}, --Livre des fantômes
						[12] = { 55022, 0, 1}, --Livre d'obstacle
						[13] = { 55023, 0, 1}, --Livre du miroir
						[14] = { 55024, 0, 1}, --Livre chute de Yangs
						[15] = { 55025, 0, 1}, --Livre de la portée
						[16] = { 55026, 0, 1}, --Livre d'invincibilité
						[17] = { 55027, 0, 1}, --Livre de soins
					}
					return listeRecompense[idRecompense]
				end
			
				if idCoffre == 50040 then --Certificat d'or
					local nombreRandom = math.random(10, 30)
					local nombreRandom2 = math.random(50, 100)
					local nombreRandom3 = math.random(150, 200)
					local listeRecompense = {
						[0] = { 27992, 0, nombreRandom}, --Perle blanche 
						[1] = { 27993, 0, nombreRandom}, --Perle bleue
						[2] = { 27994, 0, nombreRandom}, --Perle de sang
						[3] = { 39001, 0, nombreRandom}, --Pierre magique
						[4] = { 72730, 0, 5}, --Élixir de la lune (sp)
						[5] = { 72726, 0, 5}, --Elixir du soleil (sp)
						[6] = { 80007, 0, nombreRandom3}, --Lingot d'or (2m de Yangs)
						[7] = { 39044, 0, 5}, --Coffre des compétences
						[8] = { 27124, 0, nombreRandom2}, --Bandage
						[9] = { 55009, 0, 1}, --Malle livre de familier
						[10] = { 80014, 0, 1}, --Bon de DC (100)
						[11] = { 28437, 0, nombreRandom3}, --Pierre anti Monstre+4
						[12] = { 28438, 0, nombreRandom3}, --Pierre d'Evasion+4
						[13] = { 28439, 0, nombreRandom3}, --Pierre d'Esquive+4
						[14] = { 28440, 0, nombreRandom3}, --Pierre de Magie+4
						[15] = { 28441, 0, nombreRandom3}, --Pierre d'Esprit de Vie+4
						[16] = { 28442, 0, nombreRandom3}, --Pierre de Défense+4
						[17] = { 28443, 0, nombreRandom3}, --Pierre de hâte+4
						[18] = { 28444, 0, nombreRandom3}, --Pierre anti-magie+4 Armure
						[19] = { 28445, 0, nombreRandom3}, --Pierre anti-magie+4 Arme
						[20] = { 28430, 0, nombreRandom3}, --Pierre de pénétration+4
						[21] = { 28431, 0, nombreRandom3}, --Pierre Souffle mortel+4
						[22] = { 28432, 0, nombreRandom3}, --Pierre d'apaisement+4
						[23] = { 18009, 0, 1}, --Ceinture en lin+9
						[24] = { 39032, 0, nombreRandom}, --Fruit de la vie
						[25] = { 71101, 0, nombreRandom2}, --Potion de célérité
						[26] = { 50323, 0, 1}, --Coffre livre de parade
						[27] = { 50324, 0, 1}, --Coffre livre de bonus
						[28] = { 100500, 0, nombreRandom}, --Haricot dragon rose
						[29] = { 38011, 0, 1}, --Paquet de Yangs 50M
						[30] = { 72319, 0, nombreRandom}, --Extension d'inventaire
						[31] = { 55404, 0, 1}, --Oeuf de Némère
						[32] = { 55403, 0, 1}, --Oeuf de Razador
					}
					return listeRecompense[idRecompense]
				end
			
				if idCoffre == 50039 then --Certificat d'argent
					local nombreRandom = math.random(5, 15)
					local nombreRandom2 = math.random(25, 50)
					local nombreRandom3 = math.random(100, 150)
					local listeRecompense = {
						[0] = { 39006, 0, nombreRandom3}, --Cape de bravoure 
						[1] = { 72728, 0, 1}, --Élixir de la lune (m)
						[2] = { 72725, 0, 1}, --Elixir du soleil (m)
						[3] = { 80006, 0, nombreRandom2}, --Lingot d'or (1M de Yang)
						[4] = { 39030, 0, nombreRandom2}, --Lecture concentré
						[5] = { 71001, 0, nombreRandom2}, --Parchemin d'exorcisme
						[6] = { 80017, 0, 1}, --Bon de DC (50)
						[7] = { 28437, 0, nombreRandom}, --Pierre anti Monstre+4
						[8] = { 28438, 0, nombreRandom}, --Pierre d'Evasion+4
						[9] = { 28439, 0, nombreRandom}, --Pierre d'Esquive+4
						[10] = { 28440, 0, nombreRandom}, --Pierre de Magie+4
						[11] = { 28441, 0, nombreRandom}, --Pierre d'Esprit de Vie+4
						[12] = { 28442, 0, nombreRandom}, --Pierre de Défense+4
						[13] = { 28443, 0, nombreRandom}, --Pierre de hâte+4
						[14] = { 28444, 0, nombreRandom}, --Pierre anti-magie+4 Armure
						[15] = { 28445, 0, nombreRandom}, --Pierre anti-magie+4 Arme
						[16] = { 28430, 0, nombreRandom}, --Pierre de pénétration+4
						[17] = { 28431, 0, nombreRandom}, --Pierre Souffle mortel+4
						[18] = { 28432, 0, nombreRandom}, --Pierre d'apaisement+4
						[19] = { 39004, 0, nombreRandom}, --Orbe de bénédiction
						[2] = { 18000, 0, 1}, --Ceinture en lin+0
					}
					return listeRecompense[idRecompense]
				end
			
				if idCoffre == 50038 then --Certificat de bronze
					local listeRecompense = {
						[0] = { 39006, 0, 25}, --Cape de bravoure x50
						[1] = { 39040, 0, 1}, --Élixir de la lune (m)
						[2] = { 39037, 0, 1}, --Elixir du soleil (m)
						[3] = { 80005, 0, 50}, --Lingot d'or (500k de Yang)
						[4] = { 39030, 0, 10}, --Lecture concentré(x10)
						[5] = { 71001, 0, 10}, --Parchemin d'exorcisme(x10)
						[6] = { 28437, 0, 2}, --Pierre anti Monstre+4
						[7] = { 28438, 0, 2}, --Pierre d'Evasion+4
						[8] = { 28439, 0, 2}, --Pierre d'Esquive+4
						[9] = { 28440, 0, 2}, --Pierre de Magie+4
						[10] = { 28441, 0, 2}, --Pierre d'Esprit de Vie+4
						[11] = { 28442, 0, 5}, --Pierre de Défense+4
						[12] = { 28443, 0, 2}, --Pierre de hâte+4
						[13] = { 28444, 0, 2}, --Pierre anti-magie+4 Armure
						[14] = { 28445, 0, 2}, --Pierre anti-magie+4 Arme
						[15] = { 28430, 0, 5}, --Pierre de pénétration+4
						[16] = { 28431, 0, 2}, --Pierre Souffle mortel+4
						[17] = { 28432, 0, 2}, --Pierre d'apaisement+4
						[18] = { 39004, 0, 1}, --Orbe de bénédiction
					}
					return listeRecompense[idRecompense]
				end
			
				if idCoffre == 50042 then --Récompense du STAFF
					local listeRecompense = {
						[0] = { 72319, 0, 200}, --Extension d'inventaire
						[1] = { 100400, 0, 200}, --Haricot dragon bleu
						[2] = { 50132, 0, 1}, --Coffre de l'Empereur
						[1] = { 39001, 0, 200}, --Pierre magique x200
						[1] = { 80007, 0, 200}, --Lingot d'or (400M de Yangs)
						[2] = { 55004, 0, 50}, --Livre de famil. sauvage (x50)
						[3] = { 55003, 0, 50}, --Livre de jeune familier (x50)
						[1] = { 80016, 0, 1}, --Bon de DC (1.000)
						[2] = { 55406, 0, 1}, --Oeuf de la reine meley
						[3] = { 55405, 0, 1}, --Oeuf du dragon bleu
						[2] = { 55005, 0, 50}, --Livre de famil. vaillant (x50)
						[1] = { 55009, 0, 10}, --Malle livres de familier
						[2] = { 55403, 0, 10}, --Oeuf de Razador
						[1] = { 55404, 0, 10}, --Oeuf de Némère
						[3] = { 100500, 0, 200}, --Haricot dragon rose
						[3] = { 27124, 0, 200}, --Bandage
						[3] = { 50272, 0, 1}, --Coffre chass. boss or
						[1] = { 50267, 0, 1}, --Coffre d'or Okey
						[2] = { 50040, 0, 1}, --Certificats d'or
						[3] = { 50042, 0, 1}, --Récompense du staff
						[2] = { 310, 0, 1}, --Ultima Black
						[1] = { 300, 0, 1}, --Ultima White
					}
					return listeRecompense[idRecompense]
				end
			
				if idCoffre == 50271 then --Coffre du gardien dragon
					local listeRecompense = {
						[0] = { 15370, 0, 1}, --Chausses d'euphorie
						[1] = { 15430, 0, 1}, --Bottes d'oiseau-glace
						[2] = { 3190, 0, 1}, --Lame solaire+0
						[3] = { 460, 0, 1}, --Epée runique+0
						[1] = { 6090, 0, 1}, --Seigneur des dragons+0
						[2] = { 1340, 0, 1}, --Lame des cinq éléments+0
						[3] = { 30080, 0, 10}, --Livre maudit+ x10
						[1] = { 30194, 0, 5}, --Massue orque x5
						[2] = { 30089, 0, 1}, -- Fourrure de Yéti+ 
						[3] = { 30193, 0, 5}, -- Os de doigt x5
						[2] = { 30550, 0, 10}, --Lanière bleue x10
						[1] = { 55003, 0, 5}, --Livre de jeune familier
						[3] = { 55004, 0, 5}, --Livre de famil. sauvage
						[2] = { 55005, 0, 5}, --Livre de famil. vaillant
						[1] = { 30620, 0, 3}, --Corne de dragon rouge x3
						[3] = { 30621, 0, 3}, --Ecaille de dragon rouge x3
						[1] = { 50296, 0, 1}, --Boite de parade
						[2] = { 50297, 0, 1}, --Boite de bonus
						[3] = { 27992, 0, 5}, --Perle blanche
						[1] = { 27993, 0, 5}, --Perle bleue
						[2] = { 27994, 0, 5}, --Perle de sang
						[1] = { 30192, 0, 1}, --Latex
						[3] = { 30622, 0, 5}, --Plan d'armure : casque x5
						[1] = { 30042, 0, 5}, --Croc de tigre de combat x5
						[3] = { 310, 0, 1}, --Ultima Black
					}
					return listeRecompense[idRecompense]
				end
			
				if idCoffre == 38010 then --Paquet de Yangs (25M)
					local listeRecompense = {
						[0] = { 1, 0, 25000000}, --25M
						[1] = { 1, 0, 25000000}, --25M
					}
					return listeRecompense[idRecompense]
				end
			
				if idCoffre == 38011 then --Paquet de Yangs (50M)
					local listeRecompense = {
						[0] = { 1, 0, 50000000}, --50M
						[1] = { 1, 0, 50000000}, --50M
					}
					return listeRecompense[idRecompense]
				end

				if idCoffre == 38054 then --Coffre tempête du désert
					local listeRecompense = {
						[0] = { 41029, 0, 1}, --Combattant du désert+
						[1] = { 41030, 0, 1}, --Combattante du désert+
						[2] = { 39004, 0, 5}, --Orbe de bénédiction
						[3] = { 25041, 0, 3}, --Pierre magique
						[4] = { 39029, 0, 10}, --Objet de renforcement
						[5] = { 39028, 0, 10}, --Objet enchanté
						[6] = { 71004, 0, 10}, --Médaille du dragon
						[7] = { 72045, 0, 1}, --Livre du chef 3h
						[8] = { 70039, 0, 1}, --Manuel du forgeron
						[9] = { 71032, 0, 10}, --Parchemin du dieu dragon
						[10] = { 25040, 0, 10}, --Parchemin de bénédiction
						[11] = { 71095, 0, 10}, --Ticket
						[12] = { 39027, 0, 10}, --Livre des pierres
						[13] = { 71018, 0, 10}, --Bénédiction de vie
					}
					return listeRecompense[idRecompense]
				end
			
				if idCoffre == 38055 then --Caisse à petits
					local listeRecompense = {
						[0] = { 53012, 0, 1}, --Sceau Porky
						[1] = { 53011, 0, 1}, --Sceau Khan
						[2] = { 39004, 0, 10}, --Orbe de bénédiction
						[3] = { 25041, 0, 3}, --Pierre magique
						[4] = { 39029, 0, 10}, --Objet de renforcement
						[5] = { 76002, 0, 10}, --Tête réduite
						[6] = { 71004, 0, 10}, --Médaille du dragon
						[7] = { 72045, 0, 1}, --Livre du chef 3h
						[8] = { 70039, 0, 1}, --Manuel du forgeron
						[9] = { 71032, 0, 10}, --Parchemin du dieu dragon
						[10] = { 25040, 0, 10}, --Parchemin de bénédiction
						[11] = { 71095, 0, 10}, --Ticket
						[12] = { 39027, 0, 10}, --Livre des pierres
						[13] = { 71018, 0, 10}, --Bénédiction de vie
					}
					return listeRecompense[idRecompense]
				end
			
				if idCoffre == 71160 then --Coffre des Athéniens
					local listeRecompense = {
						[0] = { 27992, 0, 3}, --Perle blanche
						[1] = { 27993, 0, 3}, --Perle bleu
						[2] = { 39004, 0, 10}, --Orbe de bénédiction
						[3] = { 25041, 0, 3}, --Pierre magique
						[4] = { 39029, 0, 10}, --Objet de renforcement
						[5] = { 39028, 0, 10}, --Objet enchanté
						[6] = { 71004, 0, 5}, --Médaille du dragon x5
						[7] = { 72045, 0, 1}, --Livre du chef 3h
						[8] = { 39030, 0, 1}, --Lecture concentrée
						[9] = { 70102, 0, 1}, --Haricot Zen
						[10] = { 39005, 0, 3}, --Cuivre magique
						[11] = { 71108, 0, 50}, --Grenadine x15
						[12] = { 72723, 0, 1}, --Elixir du soleil (p)
						[13] = { 72727, 0, 1}, --Elixir de la lune (p)
						[14] = { 71026, 0, 1}, --Minerai de fer magique
						[15] = { 27994, 0, 1}, --Perle de sang
					}
					return listeRecompense[idRecompense]
				end
			
				if idCoffre == 71159 then --Coffre de Milon
					local listeRecompense = {
						[0] = { 27992, 0, 5}, --Perle blanche
						[1] = { 27993, 0, 5}, --Perle bleu
						[2] = { 39004, 0, 5}, --Orbe de bénédiction
						[3] = { 25041, 0, 5}, --Pierre magique
						[4] = { 39029, 0, 10}, --Objet de renforcement
						[5] = { 39028, 0, 10}, --Objet enchanté
						[6] = { 71004, 0, 5}, --Médaille du dragon x5
						[7] = { 72045, 0, 1}, --Livre du chef 3h
						[8] = { 39030, 0, 10}, --Lecture concentrée
						[9] = { 70102, 0, 10}, --Haricot Zen
						[10] = { 39005, 0, 10}, --Cuivre magique
						[11] = { 71108, 0, 15}, --Grenadine x15
						[12] = { 72723, 0, 1}, --Elixir du soleil (p)
						[13] = { 72727, 0, 1}, --Elixir de la lune (p)
						[14] = { 71026, 0, 10}, --Minerai de fer magique
						[15] = { 27994, 0, 10}, --Perle de sang
					}
					return listeRecompense[idRecompense]
				end
			
				if idCoffre == 50249 then --Coffre du triomphe
					local listeRecompense = {
						[0] = { 30010, 0, 10}, --Bile d'ours
						[1] = { 70048, 0, 10}, --Cape de l'évadé
						[2] = { 30035, 0, 10}, --Crème de visage
						[3] = { 30011, 0, 10}, --Pelote
						[4] = { 30006, 0, 10}, --Molaire d'orc
						[5] = { 30017, 0, 10}, --Epingle de cheveux déco.
						[6] = { 30082, 0, 10}, --Queue de serpent+
						[7] = { 30003, 0, 10}, --Groin
						[8] = { 30045, 0, 10}, --Dard de scorpion
						[9] = { 70102, 0, 10}, --Haricot Zen
						[10] = { 30038, 0, 10}, --Fourrure de tigre
						[11] = { 30070, 0, 10}, --Fourrure de loup+
						[12] = { 30151, 0, 10}, --Fourrure de loup
						[13] = { 30033, 0, 10}, --Porcelaine brisée
						[14] = { 70051, 0, 10}, --Gants du roi sage
						[15] = { 70049, 0, 10}, --Anneau de lucie
						[16] = { 25040, 0, 10}, --Parchemin de Bénédiction
					}
					return listeRecompense[idRecompense]
				end
			
				if idCoffre == 38052 then --Coffre des rois
					local listeRecompense = {
						[0] = { 71124, 0, 1}, --Lion blanc
						[1] = { 25041, 0, 1}, --Pierre magique
						[2] = { 71095, 0, 3}, --Ticket x3
						[3] = { 71004, 0, 10}, --Médaille du dragon x10
						[4] = { 71018, 0, 2}, --Bénédiction de vie x2
						[5] = { 39028, 0, 1}, --Objet enchanté
						[6] = { 39027, 0, 1}, --Livre des pierres
						[7] = { 72045, 0, 1}, --Livre du chef 3h
						[8] = { 70039, 0, 1}, --Manuel du forgeron
						[9] = { 71032, 0, 1}, --Parchemin du dieu dragon
					}
					return listeRecompense[idRecompense]
				end
			
				if idCoffre == 71191 then --Sachet de bonbons
					local listeRecompense = {
						[0] = { 27992, 0, 1}, --Perle blanche
						[1] = { 27993, 0, 1}, --Perle bleu
						[2] = { 27994, 0, 1}, --Perle de sang
						[3] = { 39005, 0, 1}, --Cuivre magique
						[4] = { 39004, 0, 1}, --Orbe de bénédiction
						[5] = { 39028, 0, 1}, --Objet enchanté
						[6] = { 39016, 0, 1}, --Minerai de fer magique
						[7] = { 39031, 0, 1}, --Potion de célérité
						[8] = { 70102, 0, 1}, --Haricot Zen
						[9] = { 76017, 0, 1}, --Potion d'attaque+10
						[10] = { 72726, 0, 1}, --Elixir du soleil (sp)
						[11] = { 72730, 0, 1}, --Elixir de la lune (sp)
						[12] = { 71004, 0, 1}, --Médaille du dragon 
						[13] = { 53235, 0, 1}, --Sceau de Robin
						[14] = { 71153, 0, 1}, --Potion de sagesse
						[15] = { 1, 0, 50000}, -- 50k Yangs
						[16] = { 1, 0, 200000}, -- 200K Yangs
						[17] = { 1, 0, 500000}, -- 500K Yangs
					}
					return listeRecompense[idRecompense]
				end
			
				if idCoffre == 38050 then --Coffre du Pouvoir
					local listeRecompense = {
						[0] = { 38051, 0, 1}, --Cristal du Tigre Royal
						[1] = { 27992, 0, 1}, --Perle blanche
						[2] = { 39029, 0, 1}, --Objet de renforcement
						[3] = { 27993, 0, 1}, --Perle bleu
						[4] = { 39004, 0, 1}, --Orbe de bénédiction
						[5] = { 27994, 0, 1}, --Perle de sang
						[6] = { 25040, 0, 1}, --Parchemin de Bénédiction
						[7] = { 39030, 0, 1}, --Lecture concentrée
						[8] = { 70039, 0, 1}, --Manuel du forgeron
						[9] = { 71032, 0, 1}, --Parchemin du dieu dragon
						[10] = { 39038, 0, 1}, --Elixir du soleil (m)
						[11] = { 39041, 0, 1}, --Elixir de la lune (m)
						[12] = { 71027, 0, 2}, --Vie du dieu dragon x2
					}
					return listeRecompense[idRecompense]
				end
			
				if idCoffre == 38051 then --Cristal du Tigre Royal
					local listeRecompense = {
						[0] = { 71137, 0, 1}, --Sceau: tigre royal bleu
						[1] = { 71138, 0, 1}, --Sceau: tigre royal rouge
						[2] = { 71139, 0, 1}, --Sceau: tigre royal or
						[3] = { 71140, 0, 1}, --Sceau: tigre royal vert
						[4] = { 71141, 0, 1}, --Sceau: tigre royal gris
						[5] = { 71142, 0, 1}, --Sceau: tigre royal blanc
					}
					return listeRecompense[idRecompense]
				end
			
				if idCoffre == 71147 then --Coffre d'amor (bleu)
					local listeRecompense = {
						[0] = { 39033, 0, 1}, --Parchemin de correction
						[1] = { 25100, 0, 1}, --Parch. Pierre d'esprit
						[2] = { 39029, 0, 1}, --Objet de renforcement
						[3] = { 39032, 0, 1}, --Fruit de la vie
						[4] = { 39004, 0, 1}, --Orbe de bénédiction
						[5] = { 39028, 0, 1}, --Objet enchanté
						[6] = { 71101, 0, 1}, --Potion de célérité
						[7] = { 39006, 0, 20}, --Cape de bravoure x20
						[8] = { 1, 0, 10000}, --10K Yangs
						[9] = { 1, 0, 20000}, --20k Yangs
						[10] = { 1, 0, 30000}, --30K Yangs
						[11] = { 1, 0, 50000}, --50k Yangs
						[12] = { 1, 0, 100000}, --100K Yangs
					}
					return listeRecompense[idRecompense]
				end
			
				if idCoffre == 71146 then --Coffre d'amor (rose)
					local listeRecompense = {
						[0] = { 39033, 0, 1}, --Parchemin de correction
						[1] = { 25100, 0, 1}, --Parch. Pierre d'esprit
						[2] = { 39029, 0, 1}, --Objet de renforcement
						[3] = { 39032, 0, 1}, --Fruit de la vie
						[4] = { 39004, 0, 1}, --Orbe de bénédiction
						[5] = { 39028, 0, 1}, --Objet enchanté
						[6] = { 71101, 0, 1}, --Potion de célérité
						[7] = { 39006, 0, 20}, --Cape de bravoure x20
						[8] = { 1, 0, 10000}, --10K Yangs
						[9] = { 1, 0, 20000}, --20k Yangs
						[10] = { 1, 0, 30000}, --30K Yangs
						[11] = { 1, 0, 50000}, --50k Yangs
						[12] = { 1, 0, 100000}, --100K Yangs
					}
					return listeRecompense[idRecompense]
				end
			
				if idCoffre == 71190 then --Boîte à citrouilles
					local listeRecompense = {
						[0] = { 39005, 0, 1}, --Cuivre magique
						[1] = { 25041, 0, 1}, --Pierre magique
						[2] = { 39029, 0, 1}, --Objet de renforcement
						[3] = { 50801, 0, 1}, --Sirop de fleur de pêcher
						[4] = { 39004, 0, 1}, --Orbe de bénédiction
						[5] = { 39028, 0, 1}, --Objet enchanté
						[6] = { 72726, 0, 1}, --Elixir du soleil (sp)
						[7] = { 72045, 0, 1}, --Livre du chef 3h
						[8] = { 72730, 0, 1}, --Elixir de la lune (sp)
						[9] = { 71004, 0, 1}, --Médaille du dragon 
						[10] = { 39030, 0, 1}, --Lecture concentrée
						[11] = { 70102, 0, 1}, --Haricot Zen
						[12] = { 27992, 0, 1}, --Perle blanche 
						[13] = { 27993, 0, 1}, --Perle bleue
						[14] = { 27994, 0, 1}, --Perle de sang 
						[15] = { 53536, 0, 1}, --Autel de Bruce
						[16] = { 53537, 0, 1}, --Autal de Wayne
						[17] = { 71136, 0, 1}, --Sucette de la force
						[18] = { 71188, 0, 1}, --Sucette magique
					}
					return listeRecompense[idRecompense]
				end
			
				if idCoffre == 53536 then --Autel de bruce
					local listeRecompense = {
						[0] = { 53233, 0, 1}, --Sceau de Bruce
						[1] = { 53233, 0, 1}, --Sceau de Bruce
					}
					return listeRecompense[idRecompense]
				end
			
				if idCoffre == 53537 then --Autel de Wayne
					local listeRecompense = {
						[0] = { 53234, 0, 1}, --Sceau de Wayne
						[1] = { 53234, 0, 1}, --Sceau de Wayne
					}
					return listeRecompense[idRecompense]
				end
				
				if idCoffre == 50265 then --Ballon de foot doré
					local listeRecompense = {
						[0] = { 39005, 0, 1}, --Cuivre magique
						[1] = { 27992, 0, 1}, --Perle blanche 
						[2] = { 27993, 0, 1}, --Perle bleue
						[3] = { 27994, 0, 1}, --Perle de sang
						[4] = { 39030, 0, 1}, --Lecture concentrée
						[5] = { 70102, 0, 1}, --Haricot Zen
						[6] = { 72045, 0, 1}, --Livre du chef 3h
						[7] = { 39028, 0, 1}, --Objet enchanté
						[8] = { 39029, 0, 1}, --Objet de renforcement
						[9] = { 71004, 0, 5}, --Médaille du dragon x5
						[10] = { 71108, 0, 5}, --Grenadine x5
						[11] = { 72723, 0, 1}, --Elixir du soleil (p)
						[12] = { 72727, 0, 1}, --Elixir de la lune (p)
						[13] = { 39004, 0, 1}, --Orbe de bénédiction
						[14] = { 39016, 0, 1}, --Minerai de fer magique
					}
					return listeRecompense[idRecompense]
				end
				
				if idCoffre == 50274 then --Coffre chass. boss bronze
					local listeRecompense = {
						[0] = { 27105, 0, 10}, --Potion violette (G)
						[1] = { 27102, 0, 10}, --Potion verte (G)
					}
					return listeRecompense[idRecompense]
				end
				
				if idCoffre == 50273 then --Coffre chass. boss argent
					local listeRecompense = {
						[0] = { 27003, 0, 200}, --Potion rouge 
						[1] = { 27006, 0, 200}, --Potion bleu
						[2] = { 71095, 0, 2}, --Ticket
						[3] = { 76017, 0, 10}, --Potion d'attaque +10
						[0] = { 39006, 0, 20}, --Cape de bravoure 
						[5] = { 25040, 0, 1}, --Parchemin de Bénédiction
						[6] = { 72045, 0, 1}, --Livre du chef 3h
						[7] = { 39026, 0, 20}, --Potion de vitesse
					}
					return listeRecompense[idRecompense]
				end
				
				if idCoffre == 50272 then --Coffre chass. boss or
					local listeRecompense = {
						[0] = { 39026, 0, 20}, --Potion de vitesse 60% x20
						[1] = { 39031, 0, 10}, --Potion de célérité x10
						[2] = { 76017, 0, 20}, --Potion d'attaque +10 
						[3] = { 72726, 0, 1}, --Elixir du soleil (sp)
						[4] = { 72730, 0, 1}, --Elixir de la lune (sp)
						[5] = { 25040, 0, 5}, --Parchemin de Bénédiction
						[6] = { 72045, 0, 1}, --Livre du chef 3h
						[7] = { 39036, 0, 1}, --Bottes du vent
						[8] = { 71032, 0, 1}, --Parchemin du dieu dragon
						[9] = { 55003, 0, 5}, --Livre de jeune familier
						[10] = { 39032, 0, 5}, --Fruit de la vie
					}
					return listeRecompense[idRecompense]
				end
				
				if idCoffre == 50132 then --Coffre de l'Empereur
					local listeRecompense = {
						[0] = { 11971, 0, 1}, --Armure de Hwang
						[1] = { 39004, 0, 1}, --Armure rouge de Hwang
						[2] = { 39031, 0, 1}, --Armure de Zin-Hwang
						[3] = { 76017, 0, 1}, --Armure de Sang-Hwang
					}
					return listeRecompense[idRecompense]
				end
				
				if idCoffre == 71204 then --Encyclo.   (Guerrier Corps à corps)
					local listeRecompense = {
						[0] = { 50401, 0, 25}, --Man. Triple Lacération
						[1] = { 50402, 0, 25}, --Man. Moulinet à lépée
						[2] = { 50403, 0, 25}, --Manuel de Berserk
						[3] = { 50404, 0, 25}, --Manuel daura de lepée
						[4] = { 50405, 0, 25}, --Manuel daccélération
						[5] = { 50406, 0, 25}, --Livre : Volonté de vivre
					}
					return listeRecompense[idRecompense]
				end
				
				if idCoffre == 71206 then --Encyclo.   (Guerrier mentaux)
					local listeRecompense = {
						[0] = { 50416, 0, 25}, --Man. attaque de lesprit
						[1] = { 50417, 0, 25}, --Manuel de la paume
						[2] = { 50418, 0, 25}, --Manuel de Charge
						[3] = { 50419, 0, 25}, --Manuel de Corps puissant
						[4] = { 50420, 0, 25}, --Man. dattaque à lepée
						[5] = { 50421, 0, 25}, --Livre : Orbe de lépée
					}
					return listeRecompense[idRecompense]
				end
				
				if idCoffre == 71208 then --Encyclo.   (Ninja assassin)
					local listeRecompense = {
						[0] = { 50431, 0, 25}, --Manuel dembuscade
						[1] = { 50432, 0, 25}, --Manuel dattaque rapide
						[2] = { 50433, 0, 25}, --Manuel de Dague filante
						[3] = { 50434, 0, 25}, --Manuel de furtivité
						[4] = { 50435, 0, 25}, --Manuel Brume empoisonnée
						[5] = { 50436, 0, 25}, --Livre : Poison insidieux
					}
					return listeRecompense[idRecompense]
				end
				
				if idCoffre == 71210 then --Encyclo.   (Ninja Archer)
					local listeRecompense = {
						[0] = { 50436, 0, 25}, --Manuel Tir à répétition
						[1] = { 50446, 0, 25}, --Manuel Pluie de flèches
						[2] = { 50447, 0, 25}, --Manuel de Flèche de Feu
						[3] = { 50448, 0, 25}, --Manuel de Pas de plume
						[4] = { 50449, 0, 25}, --Manuel Brume empoisonnée
						[5] = { 50450, 0, 25}, --Man. Flèche empoisonnée
					}
					return listeRecompense[idRecompense]
				end
				
				if idCoffre == 71212 then --Encyclo.   (Sura AM)
					local listeRecompense = {
						[0] = { 50461, 0, 25}, --Manuel Toucher brûlant
						[1] = { 50462, 0, 25}, --Man. Tourbillon du Drag.
						[2] = { 50463, 0, 25}, --Manuel de Lame enchantée
						[3] = { 50464, 0, 25}, --Manuel de Peur
						[4] = { 50465, 0, 25}, --Manuel armure enchantée
						[5] = { 50466, 0, 25}, --Manuel Contre-sortilège
					}
					return listeRecompense[idRecompense]
				end
			
				if idCoffre == 71214 then --Encyclo.   (Sura MN)
					local listeRecompense = {
						[0] = { 50476, 0, 25}, --Man. attaque Ténèbres
						[1] = { 50477, 0, 25}, --Man. attaque de flammes
						[2] = { 50478, 0, 25}, --Manuel Esprit de flammes
						[3] = { 50479, 0, 25}, --Man. Protect. Ténèbres
						[4] = { 50480, 0, 25}, --Man. frappe de lesprit
						[5] = { 50481, 0, 25}, --Man. Orbe des Ténèbres
					}
					return listeRecompense[idRecompense]
				end
				
				if idCoffre == 71216 then --Encyclo.   (Chamane DRAGON)
					local listeRecompense = {
						[0] = { 50491, 0, 25}, --Manuel Talisman volant
						[1] = { 50492, 0, 25}, --Manuel Dragon chassant
						[2] = { 50493, 0, 25}, --Manuel Dragon rugissant
						[3] = { 50494, 0, 25}, --Manuel de Bénédiction
						[4] = { 50495, 0, 25}, --Manuel de Reflet
						[5] = { 50496, 0, 25}, --Manuel Aide du Dragon
					}
					return listeRecompense[idRecompense]
				end
				
				if idCoffre == 71218 then --Encyclo.   (Chamane Soin)
					local listeRecompense = {
						[0] = { 50506, 0, 25}, --Manuel de Jet de Lumière
						[1] = { 50507, 0, 25}, --Man. appel de la Lumière
						[2] = { 50508, 0, 25}, --Manuel Griffe de Lumière
						[3] = { 50509, 0, 25}, --Manuel de Soin
						[4] = { 50510, 0, 25}, --Manuel de Promptitude
						[5] = { 50511, 0, 25}, --Manuel attaque renforcée
					}
					return listeRecompense[idRecompense]
				end
			
				if idCoffre == 71179 then --Encyclo. (Manuels lycans)
					local listeRecompense = {
						[0] = { 50530, 0, 25}, --Livre : Déchiqueter
						[1] = { 50531, 0, 25}, --Livre : Souffle de loup
						[2] = { 50532, 0, 25}, --Livre : Bond de loup
						[3] = { 50533, 0, 25}, --Livre : Griffe de loup
						[4] = { 50534, 0, 25}, --Livre : Âme loup pourpre
						[5] = { 50535, 0, 25}, --Livre : Âme loup indigo
					}
					return listeRecompense[idRecompense]
				end
				
				if idCoffre == 39044 then --Coffre des compétences
					local listeRecompense = {
						[0] = { 50530, 0, 25}, --Manuel d'équitation
						[1] = { 50531, 0, 25}, --Manuel appriv. chevaux
						[2] = { 50532, 0, 25}, --Manuel d'extraction
						[3] = { 50533, 0, 25}, --Livre de polymorphie
						[4] = { 50534, 0, 25}, --Livre polymorph. avancée
						[5] = { 50535, 0, 25}, --Livre Maître Polymorph.
						[6] = { 50535, 0, 25}, --l'art de guerre Sun-Zi
						[7] = { 50535, 0, 25}, --l'art de guerre Wu-Zi
						[8] = { 50535, 0, 25}, --WeiLiao Zi
						[9] = { 50535, 0, 25}, --Maîtrise du combo
						[10] = { 50535, 0, 25}, --Arch. Maîtres du Combo
						[11] = { 50535, 0, 25}, --Art du Combo
					}
					return listeRecompense[idRecompense]
				end
				
			end
			
			
			
			
			when 50267.use begin --Coffre de noël
				local coffreId = item.vnum 
				
				local recompenseId = math.random(0, 5)  --- génère un nombre aléatoire en fonction du nombre de récompense.
				
				local recompenseItem = Coffres_Metin2BE.Coffres_Event_Boss(coffreId, recompenseId)
				
				if recompenseItem[3] > 1 then --- vérifie si le nombre d'item est supérieur à 1.
					pc.give_item2_select(recompenseItem[1], recompenseItem[3])
				else
					pc.give_item2_select(recompenseItem[1])
				end
				if recompenseItem[2] > 0 then
					item.set_socket(0, recompenseItem[2]) 
				end
				
				pc.remove_item(coffreId) 
			end
			
			when 50126.use begin --Coffre Mystérieux
				local coffreId = item.vnum 
				
				local recompenseId = math.random(0, 12)  --- génère un nombre aléatoire en fonction du nombre de récompense.
				
				local recompenseItem = Coffres_Metin2BE.Coffres_Event_Boss(coffreId, recompenseId)
				
				if recompenseItem[3] > 1 then --- vérifie si le nombre d'item est supérieur à 1.
					pc.give_item2_select(recompenseItem[1], recompenseItem[3])
				else
					pc.give_item2_select(recompenseItem[1])
				end
				if recompenseItem[2] > 0 then
					item.set_socket(0, recompenseItem[2]) 
				end
				
				pc.remove_item(coffreId) 
			end
			
			when 50267.use begin --Coffre d'or Okey
				local coffreId = item.vnum 
				
				local recompenseId = math.random(0, 22)  --- génère un nombre aléatoire en fonction du nombre de récompense.
				
				local recompenseItem = Coffres_Metin2BE.Coffres_Event_Boss(coffreId, recompenseId)
				
				if recompenseItem[3] > 1 then --- vérifie si le nombre d'item est supérieur à 1.
					pc.give_item2_select(recompenseItem[1], recompenseItem[3])
				else
					pc.give_item2_select(recompenseItem[1])
				end
				if recompenseItem[2] > 0 then
					item.set_socket(0, recompenseItem[2]) 
				end
				
				pc.remove_item(coffreId) 
			end
			
			when 50268.use begin --Coffre d'argent Okey
				local coffreId = item.vnum 
				
				local recompenseId = math.random(0, 18)  --- génère un nombre aléatoire en fonction du nombre de récompense.
				
				local recompenseItem = Coffres_Metin2BE.Coffres_Event_Boss(coffreId, recompenseId)
				
				if recompenseItem[3] > 1 then --- vérifie si le nombre d'item est supérieur à 1.
					pc.give_item2_select(recompenseItem[1], recompenseItem[3])
				else
					pc.give_item2_select(recompenseItem[1])
				end
				if recompenseItem[2] > 0 then
					item.set_socket(0, recompenseItem[2]) 
				end
				
				pc.remove_item(coffreId) 
			end
			
			when 50269.use begin --Coffre de Bronze Okey
				local coffreId = item.vnum 
				
				local recompenseId = math.random(0, 2)  --- génère un nombre aléatoire en fonction du nombre de récompense.
				
				local recompenseItem = Coffres_Metin2BE.Coffres_Event_Boss(coffreId, recompenseId)
				
				if recompenseItem[3] > 1 then --- vérifie si le nombre d'item est supérieur à 1.
					pc.give_item2_select(recompenseItem[1], recompenseItem[3])
				else
					pc.give_item2_select(recompenseItem[1])
				end
				if recompenseItem[2] > 0 then
					item.set_socket(0, recompenseItem[2]) 
				end
				
				pc.remove_item(coffreId) 
			end
			
			
			when 50266.use begin --Coffre de Jotun
				local coffreId = item.vnum 
				
				local recompenseId = math.random(0, 28)  --- génère un nombre aléatoire en fonction du nombre de récompense.
				
				local recompenseItem = Coffres_Metin2BE.Coffres_Event_Boss(coffreId, recompenseId)
				
				if recompenseItem[3] > 1 then --- vérifie si le nombre d'item est supérieur à 1.
					pc.give_item2_select(recompenseItem[1], recompenseItem[3])
				else
					pc.give_item2_select(recompenseItem[1])
				end
				if recompenseItem[2] > 0 then
					item.set_socket(0, recompenseItem[2]) 
				end
				
				pc.remove_item(coffreId) 
			end
			
			when 50270.use begin --Coffre de la reine Meley
				local coffreId = item.vnum 
				
				local recompenseId = math.random(0, 24)  --- génère un nombre aléatoire en fonction du nombre de récompense.
				
				local recompenseItem = Coffres_Metin2BE.Coffres_Event_Boss(coffreId, recompenseId)
				
				if recompenseItem[3] > 1 then --- vérifie si le nombre d'item est supérieur à 1.
					pc.give_item2_select(recompenseItem[1], recompenseItem[3])
				else
					pc.give_item2_select(recompenseItem[1])
				end
				if recompenseItem[2] > 0 then
					item.set_socket(0, recompenseItem[2]) 
				end
				
				pc.remove_item(coffreId) 
			end
			
			when 71150.use begin --Oeuf magique
				local coffreId = item.vnum 
				
				local recompenseId = math.random(0, 23)  --- génère un nombre aléatoire en fonction du nombre de récompense.
				
				local recompenseItem = Coffres_Metin2BE.Coffres_Event_Boss(coffreId, recompenseId)
				
				if recompenseItem[3] > 1 then --- vérifie si le nombre d'item est supérieur à 1.
					pc.give_item2_select(recompenseItem[1], recompenseItem[3])
				else
					pc.give_item2_select(recompenseItem[1])
				end
				if recompenseItem[2] > 0 then
					item.set_socket(0, recompenseItem[2]) 
				end
				
				pc.remove_item(coffreId) 
			end
			
			when 55009.use begin --Malles livres de familier
				local coffreId = item.vnum 
				
				local recompenseId = math.random(0, 17)  --- génère un nombre aléatoire en fonction du nombre de récompense.
				
				local recompenseItem = Coffres_Metin2BE.Coffres_Event_Boss(coffreId, recompenseId)
				
				if recompenseItem[3] > 1 then --- vérifie si le nombre d'item est supérieur à 1.
					pc.give_item2_select(recompenseItem[1], recompenseItem[3])
				else
					pc.give_item2_select(recompenseItem[1])
				end
				if recompenseItem[2] > 0 then
					item.set_socket(0, recompenseItem[2]) 
				end
				
				pc.remove_item(coffreId) 
			end
			
			when 50040.use begin --Certificat d'or
				local coffreId = item.vnum 
				
				local recompenseId = math.random(0, 32)  --- génère un nombre aléatoire en fonction du nombre de récompense.
				
				local recompenseItem = Coffres_Metin2BE.Coffres_Event_Boss(coffreId, recompenseId)
				
				if recompenseItem[3] > 1 then --- vérifie si le nombre d'item est supérieur à 1.
					pc.give_item2_select(recompenseItem[1], recompenseItem[3])
				else
					pc.give_item2_select(recompenseItem[1])
				end
				if recompenseItem[2] > 0 then
					item.set_socket(0, recompenseItem[2]) 
				end
				
				pc.remove_item(coffreId) 
			end
			
			when 50039.use begin --Certificat d'argent
				local coffreId = item.vnum 
				
				local recompenseId = math.random(0, 19)  --- génère un nombre aléatoire en fonction du nombre de récompense.
				
				local recompenseItem = Coffres_Metin2BE.Coffres_Event_Boss(coffreId, recompenseId)
				
				if recompenseItem[3] > 1 then --- vérifie si le nombre d'item est supérieur à 1.
					pc.give_item2_select(recompenseItem[1], recompenseItem[3])
				else
					pc.give_item2_select(recompenseItem[1])
				end
				if recompenseItem[2] > 0 then
					item.set_socket(0, recompenseItem[2]) 
				end
				
				pc.remove_item(coffreId) 
			end
			
			when 50038.use begin --Certificat de bronze
				local coffreId = item.vnum 
				
				local recompenseId = math.random(0, 18)  --- génère un nombre aléatoire en fonction du nombre de récompense.
				
				local recompenseItem = Coffres_Metin2BE.Coffres_Event_Boss(coffreId, recompenseId)
				
				if recompenseItem[3] > 1 then --- vérifie si le nombre d'item est supérieur à 1.
					pc.give_item2_select(recompenseItem[1], recompenseItem[3])
				else
					pc.give_item2_select(recompenseItem[1])
				end
				if recompenseItem[2] > 0 then
					item.set_socket(0, recompenseItem[2]) 
				end
				
				pc.remove_item(coffreId) 
			end
			
			when 50271.use begin --Coffre du gardien dragon
				local coffreId = item.vnum 
				
				local recompenseId = math.random(0, 3)  --- génère un nombre aléatoire en fonction du nombre de récompense.
				
				local recompenseItem = Coffres_Metin2BE.Coffres_Event_Boss(coffreId, recompenseId)
				
				if recompenseItem[3] > 1 then --- vérifie si le nombre d'item est supérieur à 1.
					pc.give_item2_select(recompenseItem[1], recompenseItem[3])
				else
					pc.give_item2_select(recompenseItem[1])
				end
				if recompenseItem[2] > 0 then
					item.set_socket(0, recompenseItem[2]) 
				end
				
				pc.remove_item(coffreId) 
			end
			
			when 38010.use begin --Paquet de Yangs 3M
				local coffreId = item.vnum 
				
				local recompenseId = math.random(0, 1)  --- génère un nombre aléatoire en fonction du nombre de récompense.
				
				local recompenseItem = Coffres_Metin2BE.Coffres_Event_Boss(coffreId, recompenseId)
				
				if recompenseItem[3] > 1 then --- vérifie si le nombre d'item est supérieur à 1.
					pc.give_item2_select(recompenseItem[1], recompenseItem[3])
				else
					pc.give_item2_select(recompenseItem[1])
				end
				if recompenseItem[2] > 0 then
					item.set_socket(0, recompenseItem[2]) 
				end
				
				pc.remove_item(coffreId) 
			end
			
			when 38011.use begin --Paquet de Yangs 35M
				local coffreId = item.vnum 
				
				local recompenseId = math.random(0, 1)  --- génère un nombre aléatoire en fonction du nombre de récompense.
				
				local recompenseItem = Coffres_Metin2BE.Coffres_Event_Boss(coffreId, recompenseId)
				
				if recompenseItem[3] > 1 then --- vérifie si le nombre d'item est supérieur à 1.
					pc.give_item2_select(recompenseItem[1], recompenseItem[3])
				else
					pc.give_item2_select(recompenseItem[1])
				end
				if recompenseItem[2] > 0 then
					item.set_socket(0, recompenseItem[2]) 
				end
				
				pc.remove_item(coffreId) 
			end
			
			when 38054.use begin --Coffre tempête du désert
				local coffreId = item.vnum 
				
				local recompenseId = math.random(0, 13)  --- génère un nombre aléatoire en fonction du nombre de récompense.
				
				local recompenseItem = Coffres_Metin2BE.Coffres_Event_Boss(coffreId, recompenseId)
				
				if recompenseItem[3] > 1 then --- vérifie si le nombre d'item est supérieur à 1.
					pc.give_item2_select(recompenseItem[1], recompenseItem[3])
				else
					pc.give_item2_select(recompenseItem[1])
				end
				if recompenseItem[2] > 0 then
					item.set_socket(0, recompenseItem[2]) 
				end
				
				pc.remove_item(coffreId) 
			end
			
			when 38055.use begin --Caisse à petits
				local coffreId = item.vnum 
				
				local recompenseId = math.random(0, 13)  --- génère un nombre aléatoire en fonction du nombre de récompense.
				
				local recompenseItem = Coffres_Metin2BE.Coffres_Event_Boss(coffreId, recompenseId)
				
				if recompenseItem[3] > 1 then --- vérifie si le nombre d'item est supérieur à 1.
					pc.give_item2_select(recompenseItem[1], recompenseItem[3])
				else
					pc.give_item2_select(recompenseItem[1])
				end
				if recompenseItem[2] > 0 then
					item.set_socket(0, recompenseItem[2]) 
				end
				
				pc.remove_item(coffreId) 
			end
			
			when 71160.use begin --Coffre des Athéniens
				local coffreId = item.vnum 
				
				local recompenseId = math.random(0, 15)  --- génère un nombre aléatoire en fonction du nombre de récompense.
				
				local recompenseItem = Coffres_Metin2BE.Coffres_Event_Boss(coffreId, recompenseId)
				
				if recompenseItem[3] > 1 then --- vérifie si le nombre d'item est supérieur à 1.
					pc.give_item2_select(recompenseItem[1], recompenseItem[3])
				else
					pc.give_item2_select(recompenseItem[1])
				end
				if recompenseItem[2] > 0 then
					item.set_socket(0, recompenseItem[2]) 
				end
				
				pc.remove_item(coffreId) 
			end
			
			when 71159.use begin --Coffre de Milon
				local coffreId = item.vnum 
				
				local recompenseId = math.random(0, 15)  --- génère un nombre aléatoire en fonction du nombre de récompense.
				
				local recompenseItem = Coffres_Metin2BE.Coffres_Event_Boss(coffreId, recompenseId)
				
				if recompenseItem[3] > 1 then --- vérifie si le nombre d'item est supérieur à 1.
					pc.give_item2_select(recompenseItem[1], recompenseItem[3])
				else
					pc.give_item2_select(recompenseItem[1])
				end
				if recompenseItem[2] > 0 then
					item.set_socket(0, recompenseItem[2]) 
				end
				
				pc.remove_item(coffreId) 
			end
			
			when 50249.use begin --Coffre du triomphe
				local coffreId = item.vnum 
				
				local recompenseId = math.random(0, 16)  --- génère un nombre aléatoire en fonction du nombre de récompense.
				
				local recompenseItem = Coffres_Metin2BE.Coffres_Event_Boss(coffreId, recompenseId)
				
				if recompenseItem[3] > 1 then --- vérifie si le nombre d'item est supérieur à 1.
					pc.give_item2_select(recompenseItem[1], recompenseItem[3])
				else
					pc.give_item2_select(recompenseItem[1])
				end
				if recompenseItem[2] > 0 then
					item.set_socket(0, recompenseItem[2]) 
				end
				
				pc.remove_item(coffreId) 
			end
			
			when 38052.use begin --Coffre des rois
				local coffreId = item.vnum 
				
				local recompenseId = math.random(0, 9)  --- génère un nombre aléatoire en fonction du nombre de récompense.
				
				local recompenseItem = Coffres_Metin2BE.Coffres_Event_Boss(coffreId, recompenseId)
				
				if recompenseItem[3] > 1 then --- vérifie si le nombre d'item est supérieur à 1.
					pc.give_item2_select(recompenseItem[1], recompenseItem[3])
				else
					pc.give_item2_select(recompenseItem[1])
				end
				if recompenseItem[2] > 0 then
					item.set_socket(0, recompenseItem[2]) 
				end
				
				pc.remove_item(coffreId) 
			end
			
			when 71191.use begin --Sachet de bonbons
				local coffreId = item.vnum 
				
				local recompenseId = math.random(0, 17)  --- génère un nombre aléatoire en fonction du nombre de récompense.
				
				local recompenseItem = Coffres_Metin2BE.Coffres_Event_Boss(coffreId, recompenseId)
				
				if recompenseItem[3] > 1 then --- vérifie si le nombre d'item est supérieur à 1.
					pc.give_item2_select(recompenseItem[1], recompenseItem[3])
				else
					pc.give_item2_select(recompenseItem[1])
				end
				if recompenseItem[2] > 0 then
					item.set_socket(0, recompenseItem[2]) 
				end
				
				pc.remove_item(coffreId) 
			end
		
			when 38050.use begin --Coffre du pouvoir
				local coffreId = item.vnum 
				
				local recompenseId = math.random(0, 12)  --- génère un nombre aléatoire en fonction du nombre de récompense.
				
				local recompenseItem = Coffres_Metin2BE.Coffres_Event_Boss(coffreId, recompenseId)
				
				if recompenseItem[3] > 1 then --- vérifie si le nombre d'item est supérieur à 1.
					pc.give_item2_select(recompenseItem[1], recompenseItem[3])
				else
					pc.give_item2_select(recompenseItem[1])
				end
				if recompenseItem[2] > 0 then
					item.set_socket(0, recompenseItem[2]) 
				end
				
				pc.remove_item(coffreId) 
			end
			
			when 38051.use begin --Cristal du tigre royal
				local coffreId = item.vnum 
				
				local recompenseId = math.random(0, 5)  --- génère un nombre aléatoire en fonction du nombre de récompense.
				
				local recompenseItem = Coffres_Metin2BE.Coffres_Event_Boss(coffreId, recompenseId)
				
				if recompenseItem[3] > 1 then --- vérifie si le nombre d'item est supérieur à 1.
					pc.give_item2_select(recompenseItem[1], recompenseItem[3])
				else
					pc.give_item2_select(recompenseItem[1])
				end
				if recompenseItem[2] > 0 then
					item.set_socket(0, recompenseItem[2]) 
				end
				
				pc.remove_item(coffreId) 
			end
			
			when 71147.use begin --Coffre d'armor (bleu)
				local coffreId = item.vnum 
				
				local recompenseId = math.random(0, 12)  --- génère un nombre aléatoire en fonction du nombre de récompense.
				
				local recompenseItem = Coffres_Metin2BE.Coffres_Event_Boss(coffreId, recompenseId)
				
				if recompenseItem[3] > 1 then --- vérifie si le nombre d'item est supérieur à 1.
					pc.give_item2_select(recompenseItem[1], recompenseItem[3])
				else
					pc.give_item2_select(recompenseItem[1])
				end
				if recompenseItem[2] > 0 then
					item.set_socket(0, recompenseItem[2]) 
				end
				
				pc.remove_item(coffreId) 
			end
			
			when 71146.use begin --Coffre d'armor (rose)
				local coffreId = item.vnum 
				
				local recompenseId = math.random(0, 12)  --- génère un nombre aléatoire en fonction du nombre de récompense.
				
				local recompenseItem = Coffres_Metin2BE.Coffres_Event_Boss(coffreId, recompenseId)
				
				if recompenseItem[3] > 1 then --- vérifie si le nombre d'item est supérieur à 1.
					pc.give_item2_select(recompenseItem[1], recompenseItem[3])
				else
					pc.give_item2_select(recompenseItem[1])
				end
				if recompenseItem[2] > 0 then
					item.set_socket(0, recompenseItem[2]) 
				end
				
				pc.remove_item(coffreId) 
			end
			
			when 71190.use begin --Boîte à citrouilles
				local coffreId = item.vnum 
				
				local recompenseId = math.random(0, 18)  --- génère un nombre aléatoire en fonction du nombre de récompense.
				
				local recompenseItem = Coffres_Metin2BE.Coffres_Event_Boss(coffreId, recompenseId)
				
				if recompenseItem[3] > 1 then --- vérifie si le nombre d'item est supérieur à 1.
					pc.give_item2_select(recompenseItem[1], recompenseItem[3])
				else
					pc.give_item2_select(recompenseItem[1])
				end
				if recompenseItem[2] > 0 then
					item.set_socket(0, recompenseItem[2]) 
				end
				
				pc.remove_item(coffreId) 
			end
			
			when 53536.use begin --Autel de Bruce
				local coffreId = item.vnum 
				
				local recompenseId = math.random(0, 1)  --- génère un nombre aléatoire en fonction du nombre de récompense.
				
				local recompenseItem = Coffres_Metin2BE.Coffres_Event_Boss(coffreId, recompenseId)
				
				if recompenseItem[3] > 1 then --- vérifie si le nombre d'item est supérieur à 1.
					pc.give_item2_select(recompenseItem[1], recompenseItem[3])
				else
					pc.give_item2_select(recompenseItem[1])
				end
				if recompenseItem[2] > 0 then
					item.set_socket(0, recompenseItem[2]) 
				end
				
				pc.remove_item(coffreId) 
			end
			
			when 53537.use begin --Autel de Wayne
				local coffreId = item.vnum 
				
				local recompenseId = math.random(0, 1)  --- génère un nombre aléatoire en fonction du nombre de récompense.
				
				local recompenseItem = Coffres_Metin2BE.Coffres_Event_Boss(coffreId, recompenseId)
				
				if recompenseItem[3] > 1 then --- vérifie si le nombre d'item est supérieur à 1.
					pc.give_item2_select(recompenseItem[1], recompenseItem[3])
				else
					pc.give_item2_select(recompenseItem[1])
				end
				if recompenseItem[2] > 0 then
					item.set_socket(0, recompenseItem[2]) 
				end
				
				pc.remove_item(coffreId) 
			end
			
			when 50265.use begin --Ballon de foot doré
				local coffreId = item.vnum 
				
				local recompenseId = math.random(0, 15)  --- génère un nombre aléatoire en fonction du nombre de récompense.
				
				local recompenseItem = Coffres_Metin2BE.Coffres_Event_Boss(coffreId, recompenseId)
				
				if recompenseItem[3] > 1 then --- vérifie si le nombre d'item est supérieur à 1.
					pc.give_item2_select(recompenseItem[1], recompenseItem[3])
				else
					pc.give_item2_select(recompenseItem[1])
				end
				if recompenseItem[2] > 0 then
					item.set_socket(0, recompenseItem[2]) 
				end
				
				pc.remove_item(coffreId) 
			end
		
			when 50274.use begin --Coffre chass.boss bronze
				local coffreId = item.vnum 
				
				local recompenseId = math.random(0, 2)  --- génère un nombre aléatoire en fonction du nombre de récompense.
				
				local recompenseItem = Coffres_Metin2BE.Coffres_Event_Boss(coffreId, recompenseId)
				
				if recompenseItem[3] > 1 then --- vérifie si le nombre d'item est supérieur à 1.
					pc.give_item2_select(recompenseItem[1], recompenseItem[3])
				else
					pc.give_item2_select(recompenseItem[1])
				end
				if recompenseItem[2] > 0 then
					item.set_socket(0, recompenseItem[2]) 
				end
				
				pc.remove_item(coffreId) 
			end
			
			when 50273.use begin --Coffre chass.boss argent
				local coffreId = item.vnum 
				
				local recompenseId = math.random(0, 7)  --- génère un nombre aléatoire en fonction du nombre de récompense.
				
				local recompenseItem = Coffres_Metin2BE.Coffres_Event_Boss(coffreId, recompenseId)
				
				if recompenseItem[3] > 1 then --- vérifie si le nombre d'item est supérieur à 1.
					pc.give_item2_select(recompenseItem[1], recompenseItem[3])
				else
					pc.give_item2_select(recompenseItem[1])
				end
				if recompenseItem[2] > 0 then
					item.set_socket(0, recompenseItem[2]) 
				end
				
				pc.remove_item(coffreId) 
			end
			
			when 50272.use begin --Coffre chass.boss or
				local coffreId = item.vnum 
				
				local recompenseId = math.random(0, 10)  --- génère un nombre aléatoire en fonction du nombre de récompense.
				
				local recompenseItem = Coffres_Metin2BE.Coffres_Event_Boss(coffreId, recompenseId)
				
				if recompenseItem[3] > 1 then --- vérifie si le nombre d'item est supérieur à 1.
					pc.give_item2_select(recompenseItem[1], recompenseItem[3])
				else
					pc.give_item2_select(recompenseItem[1])
				end
				if recompenseItem[2] > 0 then
					item.set_socket(0, recompenseItem[2]) 
				end
				
				pc.remove_item(coffreId) 
			end
			
			when 50042.use begin --Récompense du STAFF
				local coffreId = item.vnum 
				
				local recompenseId = math.random(0, 3)  --- génère un nombre aléatoire en fonction du nombre de récompense.
				
				local recompenseItem = Coffres_Metin2BE.Coffres_Event_Boss(coffreId, recompenseId)
				
				if recompenseItem[3] > 1 then --- vérifie si le nombre d'item est supérieur à 1.
					pc.give_item2_select(recompenseItem[1], recompenseItem[3])
				else
					pc.give_item2_select(recompenseItem[1])
				end
				if recompenseItem[2] > 0 then
					item.set_socket(0, recompenseItem[2]) 
				end
				
				pc.remove_item(coffreId) 
			end
			
			when 50132.use begin --Coffre de l'Empereur
				local coffreId = item.vnum 
				
				local recompenseId = math.random(0, 3)  --- génère un nombre aléatoire en fonction du nombre de récompense.
				
				local recompenseItem = Coffres_Metin2BE.Coffres_Event_Boss(coffreId, recompenseId)
				
				if recompenseItem[3] > 1 then --- vérifie si le nombre d'item est supérieur à 1.
					pc.give_item2_select(recompenseItem[1], recompenseItem[3])
				else
					pc.give_item2_select(recompenseItem[1])
				end
				if recompenseItem[2] > 0 then
					item.set_socket(0, recompenseItem[2]) 
				end
				
				pc.remove_item(coffreId) 
			end
			
			when 71204.use begin  --Encyclo. (Guerrier Corps à corps)
				local coffreId = item.vnum 
				
				local recompenseId = math.random(0, 5)  --- génère un nombre aléatoire en fonction du nombre de récompense.
				
				local recompenseItem = Coffres_Metin2BE.Coffres_Event_Boss(coffreId, recompenseId)
				
				if recompenseItem[3] > 1 then --- vérifie si le nombre d'item est supérieur à 1.
					pc.give_item2_select(recompenseItem[1], recompenseItem[3])
				else
					pc.give_item2_select(recompenseItem[1])
				end
				if recompenseItem[2] > 0 then
					item.set_socket(0, recompenseItem[2]) 
				end
				
				pc.remove_item(coffreId) 
			end
			
			when 71206.use begin  --Encyclo. (Guerrier Mentaux)
				local coffreId = item.vnum 
				
				local recompenseId = math.random(0, 5)  --- génère un nombre aléatoire en fonction du nombre de récompense.
				
				local recompenseItem = Coffres_Metin2BE.Coffres_Event_Boss(coffreId, recompenseId)
				
				if recompenseItem[3] > 1 then --- vérifie si le nombre d'item est supérieur à 1.
					pc.give_item2_select(recompenseItem[1], recompenseItem[3])
				else
					pc.give_item2_select(recompenseItem[1])
				end
				if recompenseItem[2] > 0 then
					item.set_socket(0, recompenseItem[2]) 
				end
				
				pc.remove_item(coffreId) 
			end
			
			when 71208.use begin  --Encyclo. (Ninja assassin)
				local coffreId = item.vnum 
				
				local recompenseId = math.random(0, 5)  --- génère un nombre aléatoire en fonction du nombre de récompense.
				
				local recompenseItem = Coffres_Metin2BE.Coffres_Event_Boss(coffreId, recompenseId)
				
				if recompenseItem[3] > 1 then --- vérifie si le nombre d'item est supérieur à 1.
					pc.give_item2_select(recompenseItem[1], recompenseItem[3])
				else
					pc.give_item2_select(recompenseItem[1])
				end
				if recompenseItem[2] > 0 then
					item.set_socket(0, recompenseItem[2]) 
				end
				
				pc.remove_item(coffreId) 
			end
			
			when 71210.use begin  --Encyclo. (Ninja Archer)
				local coffreId = item.vnum 
				
				local recompenseId = math.random(0, 5)  --- génère un nombre aléatoire en fonction du nombre de récompense.
				
				local recompenseItem = Coffres_Metin2BE.Coffres_Event_Boss(coffreId, recompenseId)
				
				if recompenseItem[3] > 1 then --- vérifie si le nombre d'item est supérieur à 1.
					pc.give_item2_select(recompenseItem[1], recompenseItem[3])
				else
					pc.give_item2_select(recompenseItem[1])
				end
				if recompenseItem[2] > 0 then
					item.set_socket(0, recompenseItem[2]) 
				end
				
				pc.remove_item(coffreId) 
			end
			
			when 71212.use begin  --Encyclo. (Sura AM)
				local coffreId = item.vnum 
				
				local recompenseId = math.random(0, 5)  --- génère un nombre aléatoire en fonction du nombre de récompense.
				
				local recompenseItem = Coffres_Metin2BE.Coffres_Event_Boss(coffreId, recompenseId)
				
				if recompenseItem[3] > 1 then --- vérifie si le nombre d'item est supérieur à 1.
					pc.give_item2_select(recompenseItem[1], recompenseItem[3])
				else
					pc.give_item2_select(recompenseItem[1])
				end
				if recompenseItem[2] > 0 then
					item.set_socket(0, recompenseItem[2]) 
				end
				
				pc.remove_item(coffreId) 
			end
			
			when 71214.use begin  --Encyclo. (Sura MN)
				local coffreId = item.vnum 
				
				local recompenseId = math.random(0, 5)  --- génère un nombre aléatoire en fonction du nombre de récompense.
				
				local recompenseItem = Coffres_Metin2BE.Coffres_Event_Boss(coffreId, recompenseId)
				
				if recompenseItem[3] > 1 then --- vérifie si le nombre d'item est supérieur à 1.
					pc.give_item2_select(recompenseItem[1], recompenseItem[3])
				else
					pc.give_item2_select(recompenseItem[1])
				end
				if recompenseItem[2] > 0 then
					item.set_socket(0, recompenseItem[2]) 
				end
				
				pc.remove_item(coffreId) 
			end
			
			when 71216.use begin  --Encyclo. (Chamane DRAGON)
				local coffreId = item.vnum 
				
				local recompenseId = math.random(0, 5)  --- génère un nombre aléatoire en fonction du nombre de récompense.
				
				local recompenseItem = Coffres_Metin2BE.Coffres_Event_Boss(coffreId, recompenseId)
				
				if recompenseItem[3] > 1 then --- vérifie si le nombre d'item est supérieur à 1.
					pc.give_item2_select(recompenseItem[1], recompenseItem[3])
				else
					pc.give_item2_select(recompenseItem[1])
				end
				if recompenseItem[2] > 0 then
					item.set_socket(0, recompenseItem[2]) 
				end
				
				pc.remove_item(coffreId) 
			end
			
			when 71218.use begin  --Encyclo. (Chamane SOIN)
				local coffreId = item.vnum 
				
				local recompenseId = math.random(0, 5)  --- génère un nombre aléatoire en fonction du nombre de récompense.
				
				local recompenseItem = Coffres_Metin2BE.Coffres_Event_Boss(coffreId, recompenseId)
				
				if recompenseItem[3] > 1 then --- vérifie si le nombre d'item est supérieur à 1.
					pc.give_item2_select(recompenseItem[1], recompenseItem[3])
				else
					pc.give_item2_select(recompenseItem[1])
				end
				if recompenseItem[2] > 0 then
					item.set_socket(0, recompenseItem[2]) 
				end
				
				pc.remove_item(coffreId) 
			end
			
			when 71179.use begin --Encyclo.(Manuels lycans)
				local coffreId = item.vnum 
				
				local recompenseId = math.random(0, 5)  --- génère un nombre aléatoire en fonction du nombre de récompense.
				
				local recompenseItem = Coffres_Metin2BE.Coffres_Event_Boss(coffreId, recompenseId)
				
				if recompenseItem[3] > 1 then --- vérifie si le nombre d'item est supérieur à 1.
					pc.give_item2_select(recompenseItem[1], recompenseItem[3])
				else
					pc.give_item2_select(recompenseItem[1])
				end
				if recompenseItem[2] > 0 then
					item.set_socket(0, recompenseItem[2]) 
				end
				
				pc.remove_item(coffreId) 
			end
			
			when 39044.use begin --Coffre des compétences
				local coffreId = item.vnum 
				
				local recompenseId = math.random(0, 11)  --- génère un nombre aléatoire en fonction du nombre de récompense.
				
				local recompenseItem = Coffres_Metin2BE.Coffres_Event_Boss(coffreId, recompenseId)
				
				if recompenseItem[3] > 1 then --- vérifie si le nombre d'item est supérieur à 1.
					pc.give_item2_select(recompenseItem[1], recompenseItem[3])
				else
					pc.give_item2_select(recompenseItem[1])
				end
				if recompenseItem[2] > 0 then
					item.set_socket(0, recompenseItem[2]) 
				end
				
				pc.remove_item(coffreId) 
			end
			
			
		end
	end
	
--Coffres d'évènements & Gros BOSS
--Création pour le gérant de Ping-Hosting.com