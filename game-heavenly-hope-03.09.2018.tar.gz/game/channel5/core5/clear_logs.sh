rm -rf log/*
rm -rf packet_info.txt
rm -rf syserr
rm -rf syslog
rm -rf stdout
rm -rf PTS
rm -rf p2p_packet_info.txt
rm -rf game.core