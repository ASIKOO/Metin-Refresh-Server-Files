#!/bin/sh
cd ./g1/auth
./clear_logs.sh
cd ../db
./clear_logs.sh
cd /home/game/channel1/core1
./clear_logs.sh
cd /home/game/channel1/core2
./clear_logs.sh
cd /home/game/channel1/core3
./clear_logs.sh
cd /home/game/channel1/core4
./clear_logs.sh
cd /home/game/channel1/core5
./clear_logs.sh

cd /home/game/channel2/core1
./clear_logs.sh
cd /home/game/channel2/core2
./clear_logs.sh
cd /home/game/channel2/core3
./clear_logs.sh
cd /home/game/channel2/core4
./clear_logs.sh
cd /home/game/channel2/core5
./clear_logs.sh

cd /home/game/channel3/core1
./clear_logs.sh
cd /home/game/channel3/core2
./clear_logs.sh
cd /home/game/channel3/core3
./clear_logs.sh
cd /home/game/channel3/core4
./clear_logs.sh
cd /home/game/channel3/core5
./clear_logs.sh

cd /home/game/channel4/core1
./clear_logs.sh
cd /home/game/channel4/core2
./clear_logs.sh
cd /home/game/channel4/core3
./clear_logs.sh
cd /home/game/channel4/core4
./clear_logs.sh
cd /home/game/channel4/core5
./clear_logs.sh

cd /home/game/channel5/core1
./clear_logs.sh
cd /home/game/channel5/core2
./clear_logs.sh
cd /home/game/channel5/core3
./clear_logs.sh
cd /home/game/channel5/core4
./clear_logs.sh
cd /home/game/channel5/core5
./clear_logs.sh

cd /home/game/game99
./clear_logs.sh
echo -e "\033[31m \n Supression des Syserr/Syslog ..\033[0m"
