add_goto_info("a1|��������", 0, 1, 4693, 9642)
add_goto_info("a3|�ھ���", 0, 3, 3608, 8776)
add_goto_info("b1|��������", 0, 21, 557, 1579)
add_goto_info("b3|������", 0, 23, 1385, 2349)
add_goto_info("c1|������", 0, 41, 9696, 2784)
add_goto_info("c3|�ڶ���", 0, 43, 8731, 2426)
add_goto_info("mountain", 1, 61, 4342, 2906)
add_goto_info("mountain", 2, 61, 3752, 1749)
add_goto_info("mountain", 3, 61, 4918, 1736)
add_goto_info("flame", 1, 62, 5994, 7563)
add_goto_info("flame", 2, 62, 5978, 6222)
add_goto_info("flame", 3, 62, 7307, 6898)
add_goto_info("flame2", 0, 75, 4608, 10496)
add_goto_info("desert", 1, 63, 2178, 6272)
add_goto_info("desert", 2, 63, 2219, 5027)
add_goto_info("desert", 3, 63, 3440, 5025)
add_goto_info("orc|valley", 1, 64, 4021, 6739)
add_goto_info("orc|valley", 2, 64, 2704, 7399)
add_goto_info("orc|valley", 3, 64, 3213, 8080)
add_goto_info("temple", 0, 65, 5536, 1436)
add_goto_info("temple2", 0, 78, 1536, 10496)
add_goto_info("heaven|hl", 0, 64, 2842, 8105)
add_goto_info("heaven2|hl2", 0, 73, 2410, 12748)
add_goto_info("hlboss|dragonroom", 0, 207, 8440, 10669)
add_goto_info("trent|forest", 0 , 67, 2887 , 57 )
add_goto_info("trent2|redwood",0 , 68, 11199 , 708 )
add_goto_info("dt", 0 , 65, 5905, 1106 )
add_goto_info("dc", 0 , 206, 3145, 12095 )
add_goto_info("sd1", 0, 104, 917, 5253 )
add_goto_info("sd2", 0, 71, 7041, 4641 )
add_goto_info("giants", 0, 70, 8400, 7200)
add_goto_info("snake", 0, 69, 10496, 7168)
add_goto_info("purgatoire", 0, 251, 7674, 6344)
add_goto_info("donjonneige", 0, 195, 5520, 1946)
add_goto_info("bayblack", 0, 140, 10873, 16554)
add_goto_info("capedragon", 0, 141, 11053, 17895)
add_goto_info("misty", 0, 142, 11776 ,16640)
add_goto_info("thunder", 0, 143, 11337, 16547)
add_goto_info("football", 0, 212 , 97040, 0)
add_goto_info("gm1", 0, 103, 400, 600)
add_goto_info("gm2", 0, 105, 200, 128)
add_goto_info("duel", 0, 112, 8574, 126)
add_goto_info("OXEVENT", 0, 113, 8964, 215)
add_goto_info("wedding", 0, 81, 8250, 25)
add_goto_info("throne", 0, 213, 8057, 172)
add_goto_info("pvp", 0, 26, 8448, 8448)
add_goto_info("mistydungeon", 0, 252, 8032, 14997)
add_goto_info("jaune", 0, 259, 16226, 16172)
add_goto_info("bleu", 0, 259, 16097, 15199)
add_goto_info("rouge", 0, 259, 15467, 15504)

add_goto_info("sd3", 0, 193, 959, 5710)

add_goto_info("ta1", 0, 209, 171, 3785 )
add_goto_info("ta2", 0, 210, 171+512, 3785 )
add_goto_info("ta3", 0, 211, 171+1024, 3785 )

add_goto_info("fp1", 0, 115, 10240+82, 1024+235 )
add_goto_info("fp2", 0, 116, 10240+82, 2048+235 )
add_goto_info("fp3", 0, 117, 10240+82, 2048+235 )
add_goto_info("sungzi|����",0 , 114, 9216+250, 0+250 )
add_goto_info("fh1", 0, 118, 11264+250, 1024 + 800 )
add_goto_info("fh2", 0, 119, 11264+250, 2048 + 800 )
add_goto_info("fh3", 0, 120, 11264+250, 3072 + 800 )
add_goto_info("sungzisnow", 0,121, 11520+450, 0+250 )
add_goto_info("fs1", 0, 122, 11776+225, 1024 + 655 )
add_goto_info("fs2", 0, 123, 11776+225, 2048 + 655 )
add_goto_info("fs3", 0, 124, 11776+225, 3072 + 655 )
add_goto_info("sungzidesert", 0,125, 12288+450, 0+250 )
add_goto_info("fd1", 0, 126, 12288+225, 1024 + 655 )
add_goto_info("fd2", 0, 127, 12288+225, 2048 + 655 )
add_goto_info("fd3", 0, 128, 12288+225, 3072 + 655 )

add_goto_info("castle1", 0, 181, 9728, 1024)
add_goto_info("castle2", 0, 182, 9216, 1536)
add_goto_info("castle3", 0, 183, 9728, 1536)

add_goto_info("��峻��", 0, 150, 7936, 0)

add_goto_info("em1", 0, 181, 1024+225, 3328+225 )
add_goto_info("em1", 0, 182, 1792+225, 3328+225 )
add_goto_info("em1", 0, 183, 2560+225, 3328+225 )

arena.add_map(112, 8534, 101, 8564, 101)
arena.add_map(112, 8584, 101, 8614, 101)
arena.add_map(112, 8534, 155, 8564, 155)
arena.add_map(112, 8584, 155, 8514, 155)

arena.add_map(26, 8561, 8548, 8536, 8548)
arena.add_map(26, 8561, 8600, 8536, 8600)
arena.add_map(26, 8588, 8600, 8612, 8600)
arena.add_map(26, 8612, 8548, 8588, 8548)

-- Dragon Setting
--Metin of Heights
--Metin of Pride
--Metin of Vengeance
--Metin of Solitude

BlueDragonSetting = {}

BlueDragonSetting.hp_period = {}
BlueDragonSetting.hp_period[1] = {}
BlueDragonSetting.hp_period[1].min = 98
BlueDragonSetting.hp_period[1].max = 100
BlueDragonSetting.hp_period[1].pct = 0
BlueDragonSetting.hp_period[2] = {}
BlueDragonSetting.hp_period[2].min = 76
BlueDragonSetting.hp_period[2].max = 97
BlueDragonSetting.hp_period[2].pct = 5
BlueDragonSetting.hp_period[3] = {}
BlueDragonSetting.hp_period[3].min = 31
BlueDragonSetting.hp_period[3].max = 75
BlueDragonSetting.hp_period[3].pct = 10
BlueDragonSetting.hp_period[4] = {}
BlueDragonSetting.hp_period[4].min = 30
BlueDragonSetting.hp_period[4].max = 0
BlueDragonSetting.hp_period[4].pct = 20

BlueDragonSetting.hp_damage = {}
BlueDragonSetting.hp_damage[1] = {}
BlueDragonSetting.hp_damage[1].min = 98
BlueDragonSetting.hp_damage[1].max = 100
BlueDragonSetting.hp_damage[1].pct = 0
BlueDragonSetting.hp_damage[2] = {}
BlueDragonSetting.hp_damage[2].min = 76
BlueDragonSetting.hp_damage[2].max = 97
BlueDragonSetting.hp_damage[2].pct = 5
BlueDragonSetting.hp_damage[3] = {}
BlueDragonSetting.hp_damage[3].min = 31
BlueDragonSetting.hp_damage[3].max = 75
BlueDragonSetting.hp_damage[3].pct = 10
BlueDragonSetting.hp_damage[4] = {}
BlueDragonSetting.hp_damage[4].min = 0
BlueDragonSetting.hp_damage[4].max = 30
BlueDragonSetting.hp_damage[4].pct = 20

BlueDragonSetting.hp_regen = {}
BlueDragonSetting.hp_regen[1] = {}
BlueDragonSetting.hp_regen[1].min = 98
BlueDragonSetting.hp_regen[1].max = 100
BlueDragonSetting.hp_regen[1].pct = 0
BlueDragonSetting.hp_regen[2] = {}
BlueDragonSetting.hp_regen[2].min = 76
BlueDragonSetting.hp_regen[2].max = 97
BlueDragonSetting.hp_regen[2].pct = 4
BlueDragonSetting.hp_regen[3] = {}
BlueDragonSetting.hp_regen[3].min = 31
BlueDragonSetting.hp_regen[3].max = 75
BlueDragonSetting.hp_regen[3].pct = 8
BlueDragonSetting.hp_regen[4] = {}
BlueDragonSetting.hp_regen[4].min = 0
BlueDragonSetting.hp_regen[4].max = 30
BlueDragonSetting.hp_regen[4].pct = 12

BlueDragonSetting.Skill0 = {}
BlueDragonSetting.Skill0.period = {}
BlueDragonSetting.Skill0.period.min = 30
BlueDragonSetting.Skill0.period.max = 35
BlueDragonSetting.Skill0.damage_area = 50*100
BlueDragonSetting.Skill0.default_damage = {}
BlueDragonSetting.Skill0.default_damage.min = 4000
BlueDragonSetting.Skill0.default_damage.max = 5700
BlueDragonSetting.Skill0.damage = {}
BlueDragonSetting.Skill0.damage.musa = {}
BlueDragonSetting.Skill0.damage.musa.min = 15
BlueDragonSetting.Skill0.damage.musa.max = 20
BlueDragonSetting.Skill0.damage.assa = {}
BlueDragonSetting.Skill0.damage.assa.min = 9
BlueDragonSetting.Skill0.damage.assa.max = 14
BlueDragonSetting.Skill0.damage.sura = {}
BlueDragonSetting.Skill0.damage.sura.min = 12
BlueDragonSetting.Skill0.damage.sura.max = 17
BlueDragonSetting.Skill0.damage.muda = {}
BlueDragonSetting.Skill0.damage.muda.min = 9
BlueDragonSetting.Skill0.damage.muda.max = 14
BlueDragonSetting.Skill0.gender = {}
BlueDragonSetting.Skill0.gender.male = {}
BlueDragonSetting.Skill0.gender.male.min = 10
BlueDragonSetting.Skill0.gender.male.max = 15
BlueDragonSetting.Skill0.gender.female = {}
BlueDragonSetting.Skill0.gender.female.min = 10
BlueDragonSetting.Skill0.gender.female.max = 15

BlueDragonSetting.Skill1 = {}
BlueDragonSetting.Skill1.period = {}
BlueDragonSetting.Skill1.period.min = 10
BlueDragonSetting.Skill1.period.max = 15
BlueDragonSetting.Skill1.damage_area = 35*100
BlueDragonSetting.Skill1.default_damage = {}
BlueDragonSetting.Skill1.default_damage.min = 5500
BlueDragonSetting.Skill1.default_damage.max = 7000

BlueDragonSetting.Skill2 = {}
BlueDragonSetting.Skill2.period = {}
BlueDragonSetting.Skill2.period.min = 35
BlueDragonSetting.Skill2.period.max = 45
BlueDragonSetting.Skill2.damage_area = 30*100
BlueDragonSetting.Skill2.default_damage = {}
BlueDragonSetting.Skill2.default_damage.min = 2000
BlueDragonSetting.Skill2.default_damage.max = 3600
BlueDragonSetting.Skill2.stun_time = {}
BlueDragonSetting.Skill2.stun_time.default = {}
BlueDragonSetting.Skill2.stun_time.default.min = 1
BlueDragonSetting.Skill2.stun_time.default.max = 2
BlueDragonSetting.Skill2.stun_time.musa = {}
BlueDragonSetting.Skill2.stun_time.musa.min = 3
BlueDragonSetting.Skill2.stun_time.musa.max = 4
BlueDragonSetting.Skill2.stun_time.assa = {}
BlueDragonSetting.Skill2.stun_time.assa.min = 1
BlueDragonSetting.Skill2.stun_time.assa.max = 2
BlueDragonSetting.Skill2.stun_time.sura = {}
BlueDragonSetting.Skill2.stun_time.sura.min = 2
BlueDragonSetting.Skill2.stun_time.sura.max = 3
BlueDragonSetting.Skill2.stun_time.muda = {}
BlueDragonSetting.Skill2.stun_time.muda.min = 1
BlueDragonSetting.Skill2.stun_time.muda.max = 2
BlueDragonSetting.Skill2.gender = {}
BlueDragonSetting.Skill2.gender.male = {}
BlueDragonSetting.Skill2.gender.male.min = 1
BlueDragonSetting.Skill2.gender.male.max = 2
BlueDragonSetting.Skill2.gender.female = {}
BlueDragonSetting.Skill2.gender.female.min = 1
BlueDragonSetting.Skill2.gender.female.max = 2

BlueDragonSetting.DragonStone = {}

BlueDragonSetting.DragonStone[1] = {}
BlueDragonSetting.DragonStone[1].vnum = 8031
BlueDragonSetting.DragonStone[1].effect_type = 1
BlueDragonSetting.DragonStone[1].val = 15
BlueDragonSetting.DragonStone[1].enemy = 20110
BlueDragonSetting.DragonStone[1].enemy_val = 3
BlueDragonSetting.DragonStone[2] = {}
BlueDragonSetting.DragonStone[2].vnum = 8032
BlueDragonSetting.DragonStone[2].effect_type = 2
BlueDragonSetting.DragonStone[2].val = 15
BlueDragonSetting.DragonStone[2].enemy = 20111
BlueDragonSetting.DragonStone[2].enemy_val = 3
BlueDragonSetting.DragonStone[3] = {}
BlueDragonSetting.DragonStone[3].vnum = 8033
BlueDragonSetting.DragonStone[3].effect_type = 3
BlueDragonSetting.DragonStone[3].val = 10
BlueDragonSetting.DragonStone[3].enemy = 20112
BlueDragonSetting.DragonStone[3].enemy_val = 3
BlueDragonSetting.DragonStone[4] = {}
BlueDragonSetting.DragonStone[4].vnum = 8034
BlueDragonSetting.DragonStone[4].effect_type = 4
BlueDragonSetting.DragonStone[4].val = 5
BlueDragonSetting.DragonStone[4].enemy = 20113
BlueDragonSetting.DragonStone[4].enemy_val = 3

-- Skill0 = Breath
-- Skill1 = Wirbel
-- Skill2 = Earthquake


add_bgm_info( 1, "enter_the_east.mp3", 0.5);
add_bgm_info( 7, "misty_forest.mp3", 0.5);
add_bgm_info(21, "enter_the_east.mp3", 0.5);
add_bgm_info(27, "misty_forest.mp3", 0.5);
add_bgm_info(41, "enter_the_east.mp3", 0.5);
add_bgm_info(47, "misty_forest.mp3", 0.5);
add_bgm_info( 3, "back_to_back.mp3", 0.5);
add_bgm_info(23, "back_to_back.mp3", 0.5);
add_bgm_info(43, "back_to_back.mp3", 0.5);
add_bgm_info(63, "open_the_gate.mp3", 0.5);
add_bgm_info(69, "open_the_gate.mp3", 0.5);
add_bgm_info(70, "open_the_gate.mp3", 0.5);
add_bgm_info(67, "a_rhapsody_of_war.mp3", 0.5);
add_bgm_info(68, "lost_my_name.mp3", 0.5);
add_bgm_info(65, "wonderland.mp3", 0.5);
add_bgm_info(61, "mountain_of_death.mp3", 0.5);
add_bgm_info(64, "save_me.mp3", 0.5);
add_bgm_info(72, "mountain_of_death.mp3", 0.5);
add_bgm_info(73, "mountain_of_death.mp3", 0.5);
add_bgm_info(74, "mountain_of_death.mp3", 0.5);
add_bgm_info(75, "follow_war_god.mp3", 0.5);
add_bgm_info(76, "mountain_of_death.mp3", 0.5);
add_bgm_info(77, "save_me.mp3", 0.5);
add_bgm_info(78, "wonderland.mp3", 0.5);
add_bgm_info(104, "Only_my_battle.mp3", 0.5);
add_bgm_info(62, "follow_war_god.mp3", 0.5);
add_bgm_info(66, "death_of_landmark.mp3", 0.5);
add_bgm_info(107, "monkey_temple.mp3", 0.5);
add_bgm_info(108, "monkey_temple.mp3", 0.5);
add_bgm_info(109, "monkey_temple.mp3", 0.5);
add_bgm_info(114, "last-war2.mp3", 0.5);
add_bgm_info(115, "last-war2.mp3", 0.5);
add_bgm_info(116, "last-war2.mp3", 0.5);
add_bgm_info(117, "last-war2.mp3", 0.5);
add_bgm_info(118, "last-war2.mp3", 0.5);
add_bgm_info(119, "last-war2.mp3", 0.5);
add_bgm_info(120, "last-war2.mp3", 0.5);
add_bgm_info(121, "last-war2.mp3", 0.5);
add_bgm_info(122, "last-war2.mp3", 0.5);
add_bgm_info(123, "last-war2.mp3", 0.5);
add_bgm_info(124, "last-war2.mp3", 0.5);
add_bgm_info(125, "last-war2.mp3", 0.5);
add_bgm_info(126, "last-war2.mp3", 0.5);
add_bgm_info(127, "last-war2.mp3", 0.5);
add_bgm_info(128, "last-war2.mp3", 0.5);
add_bgm_info(181, "last-war2.mp3", 0.5);
add_bgm_info(182, "last-war2.mp3", 0.5);
add_bgm_info(183, "last-war2.mp3", 0.5);
add_bgm_info(206, "catacomb_of_devil.mp3", 1);
add_bgm_info(251, "dungeon_fire.mp3", 1);
add_bgm_info(142, "misty_forest.mp3", 1);
add_bgm_info(140, "blacksea.mp3", 1);
add_bgm_info(141, "another_way.mp3", 1);
add_bgm_info(143, "mt.mp3", 1);
add_bgm_info(253, "misty_forest.mp3", 1);
add_bgm_info(258, "dungeon_terra.mp3", 1);
add_bgm_info(259, "dungeon_terra.mp3", 1);
set_bgm_volume_enable();
