#!/bin/sh


echo -e "\033[31m  
Choisissez le channel a lancer ? \n 
1 - (1) Channel 1 \n 
2 - (2) Channel 2 \n
3 - (3) Channel 3 \n
4 - (4) Channel 4 \n
5 - (5) Channel 5 \n
6 - (6) Tous \033[0m"


read chs

case $chs in 
1*)
	echo -e "\033[31m Lancement base de donn�e ..\033[0m"
	cd ./g1/db && ./db &
	sleep 2
	clear
	echo -e "\033[31m \n Lancement Auth ..\033[0m"
	cd ./g1/auth 
	./auth &
	sleep 2
	clear
	echo -e "\033[31m \n Lancement Channel1 Core1..\033[0m"
	cd /home/game/channel1/core1/
	./game &
	sleep 2
	clear
	echo -e "\033[31m \n Lancement Channel1 Core2..\033[0m"
	cd /home/game/channel1/core2/
	./game &
	sleep 2
	clear
	echo -e "\033[31m \n Lancement Channel1 Core3..\033[0m"
	cd /home/game/channel1/core3/
	./game &
	sleep 2
	clear
	echo -e "\033[31m \n Lancement Channel1 Core4..\033[0m"
	cd /home/game/channel1/core4/
	./game &
	sleep 2
	clear
	echo -e "\033[31m \n Lancement Channel1 Core5..\033[0m"
	cd /home/game/channel1/core5/
	./game &
	sleep 2
	clear
	echo -e "\033[31m \n Lancement CH99 ..\033[0m"
	cd /home/game/game99/
	./game &
	sleep 2
	clear
	echo -e "\033[32m \n Le channel 1 est lanc�!\033[0m";;
2*)
	echo -e "\033[31m \n Lancement Channel2 Core1..\033[0m"
	cd /home/game/channel2/core1/
	./game &
	sleep 2
	clear
	echo -e "\033[31m \n Lancement Channel2 Core2..\033[0m"
	cd /home/game/channel2/core2/
	./game &
	sleep 2
	clear
	echo -e "\033[31m \n Lancement Channel2 Core3..\033[0m"
	cd /home/game/channel2/core3/
	./game &
	sleep 2
	clear
	echo -e "\033[31m \n Lancement Channel2 Core4..\033[0m"
	cd /home/game/channel2/core4/
	./game &
	sleep 2
	clear
	echo -e "\033[31m \n Lancement Channel2 Core5..\033[0m"
	cd /home/game/channel2/core5/
	./game &
	sleep 2
	clear
	echo -e "\033[32m \n Le channel 2 est lanc�!\033[0m"
;;
3*)
	echo -e "\033[31m \n Lancement Channel3 Core1..\033[0m"
	cd /home/game/channel3/core1/
	./game &
	sleep 2
	clear
	echo -e "\033[31m \n Lancement Channel3 Core2..\033[0m"
	cd /home/game/channel3/core2/
	./game &
	sleep 2
	clear
	echo -e "\033[31m \n Lancement Channel3 Core3..\033[0m"
	cd /home/game/channel3/core3/
	./game &
	sleep 2
	clear
	echo -e "\033[31m \n Lancement Channel3 Core4..\033[0m"
	cd /home/game/channel3/core4/
	./game &
	sleep 2
	clear
	echo -e "\033[31m \n Lancement Channel3 Core5..\033[0m"
	cd /home/game/channel3/core5/
	./game &
	sleep 2
	clear
	echo -e "\033[32m \n Le channel 3 est lanc�!\033[0m"
;;
4*)
	echo -e "\033[31m \n Lancement Channel4 Core1..\033[0m"
	cd /home/game/channel4/core1/
	./game &
	sleep 2
	clear
	echo -e "\033[31m \n Lancement Channel4 Core2..\033[0m"
	cd /home/game/channel4/core2/
	./game &
	sleep 2
	clear
	echo -e "\033[31m \n Lancement Channel4 Core3..\033[0m"
	cd /home/game/channel4/core3/
	./game &
	sleep 2
	clear
	echo -e "\033[31m \n Lancement Channel4 Core4..\033[0m"
	cd /home/game/channel4/core4/
	./game &
	sleep 2
	clear
	echo -e "\033[31m \n Lancement Channel4 Core5..\033[0m"
	cd /home/game/channel4/core5/
	./game &
	sleep 2
	clear
	echo -e "\033[32m \n Le channel 4 est lanc�!\033[0m"
;;
5*)
	echo -e "\033[31m \n Lancement Channel5 Core1..\033[0m"
	cd /home/game/channel5/core1/
	./game &
	sleep 2
	clear
	echo -e "\033[31m \n Lancement Channel5 Core2..\033[0m"
	cd /home/game/channel5/core2/
	./game &
	sleep 2
	clear
	echo -e "\033[31m \n Lancement Channel5 Core3..\033[0m"
	cd /home/game/channel5/core3/
	./game &
	sleep 2
	clear
	echo -e "\033[31m \n Lancement Channel5 Core4..\033[0m"
	cd /home/game/channel5/core4/
	./game &
	sleep 2
	clear
	echo -e "\033[31m \n Lancement Channel5 Core5..\033[0m"
	cd /home/game/channel5/core5/
	./game &
	sleep 2
	clear
	echo -e "\033[32m \n Le channel 5 est lanc�!\033[0m"
;;
6*)
	echo -e "\033[31m Lancement base de donn�e ..\033[0m"
	cd ./g1/db && ./db &
	sleep 2
	clear
	echo -e "\033[31m \n Lancement Auth ..\033[0m"
	cd ./g1/auth 
	./auth &
	sleep 2
	clear
	echo -e "\033[31m \n Lancement Channel1 Core1..\033[0m"
	cd /home/game/channel1/core1/
	./game &
	sleep 2
	clear
	echo -e "\033[31m \n Lancement Channel1 Core2..\033[0m"
	cd /home/game/channel1/core2/
	./game &
	sleep 2
	clear
	echo -e "\033[31m \n Lancement Channel1 Core3..\033[0m"
	cd /home/game/channel1/core3/
	./game &
	sleep 2
	clear
	echo -e "\033[31m \n Lancement Channel1 Core4..\033[0m"
	cd /home/game/channel1/core4/
	./game &
	sleep 2
	clear
	echo -e "\033[31m \n Lancement Channel1 Core5..\033[0m"
	cd /home/game/channel1/core5/
	./game &
	sleep 2
	clear
	echo -e "\033[31m \n Lancement CH99 ..\033[0m"
	cd /home/game/game99/
	./game &
	sleep 2
	clear
	echo -e "\033[32m \n Le channel 1 est lanc�!\033[0m"
	echo -e "\033[31m \n Lancement Channel2 Core1..\033[0m"
	cd /home/game/channel2/core1/
	./game &
	sleep 2
	clear
	echo -e "\033[31m \n Lancement Channel2 Core2..\033[0m"
	cd /home/game/channel2/core2/
	./game &
	sleep 2
	clear
	echo -e "\033[31m \n Lancement Channel2 Core3..\033[0m"
	cd /home/game/channel2/core3/
	./game &
	sleep 2
	clear
	echo -e "\033[31m \n Lancement Channel2 Core4..\033[0m"
	cd /home/game/channel2/core4/
	./game &
	sleep 2
	clear
	echo -e "\033[31m \n Lancement Channel2 Core5..\033[0m"
	cd /home/game/channel2/core5/
	./game &
	sleep 2
	clear
	echo -e "\033[32m \n Le channel 2 est lanc�!\033[0m"
	echo -e "\033[31m \n Lancement Channel3 Core1..\033[0m"
	cd /home/game/channel3/core1/
	./game &
	sleep 2
	clear
	echo -e "\033[31m \n Lancement Channel3 Core2..\033[0m"
	cd /home/game/channel3/core2/
	./game &
	sleep 2
	clear
	echo -e "\033[31m \n Lancement Channel3 Core3..\033[0m"
	cd /home/game/channel3/core3/
	./game &
	sleep 2
	clear
	echo -e "\033[31m \n Lancement Channel3 Core4..\033[0m"
	cd /home/game/channel3/core4/
	./game &
	sleep 2
	clear
	echo -e "\033[31m \n Lancement Channel3 Core5..\033[0m"
	cd /home/game/channel3/core5/
	./game &
	sleep 2
	clear
	echo -e "\033[32m \n Le channel 3 est lanc�!\033[0m"
	echo -e "\033[31m \n Lancement Channel4 Core1..\033[0m"
	cd /home/game/channel4/core1/
	./game &
	sleep 2
	clear
	echo -e "\033[31m \n Lancement Channel4 Core2..\033[0m"
	cd /home/game/channel4/core2/
	./game &
	sleep 2
	clear
	echo -e "\033[31m \n Lancement Channel4 Core3..\033[0m"
	cd /home/game/channel4/core3/
	./game &
	sleep 2
	clear
	echo -e "\033[31m \n Lancement Channel4 Core4..\033[0m"
	cd /home/game/channel4/core4/
	./game &
	sleep 2
	clear
	echo -e "\033[31m \n Lancement Channel4 Core5..\033[0m"
	cd /home/game/channel4/core5/
	./game &
	sleep 2
	clear
	echo -e "\033[32m \n Le channel 4 est lanc�!\033[0m"
	echo -e "\033[31m \n Lancement Channel5 Core1..\033[0m"
	cd /home/game/channel5/core1/
	./game &
	sleep 2
	clear
	echo -e "\033[31m \n Lancement Channel5 Core2..\033[0m"
	cd /home/game/channel5/core2/
	./game &
	sleep 2
	clear
	echo -e "\033[31m \n Lancement Channel5 Core3..\033[0m"
	cd /home/game/channel5/core3/
	./game &
	sleep 2
	clear
	echo -e "\033[31m \n Lancement Channel5 Core4..\033[0m"
	cd /home/game/channel5/core4/
	./game &
	sleep 2
	clear
	echo -e "\033[31m \n Lancement Channel5 Core5..\033[0m"
	cd /home/game/channel5/core5/
	./game &
	sleep 2
	clear
	echo -e "\033[32m \n Le channel 5 est lanc�!\033[0m"
;;

esac
