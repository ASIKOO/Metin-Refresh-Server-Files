killall game
sleep 120
killall db
